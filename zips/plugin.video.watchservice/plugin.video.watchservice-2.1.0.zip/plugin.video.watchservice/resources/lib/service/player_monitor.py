# -*- coding: utf-8 -*-
"""The single player monitor.

Refactor of the original WSPlayer: on each Kodi player callback it resolves
identity and position ONCE, packs a `PlayerEvent`, and dispatches it to every
sink. The subtle, hard-won rules are preserved verbatim from the old service.py:

  * identity comes from the item's own InfoTag first (so any Kodi playback is
    covered), with the `TMDbHelper.Player.*` window properties as a fallback;
  * both identity and position are captured while the player is alive and
    replayed on stop, because `getVideoInfoTag()` raises and `getTime()` is
    unreliable once Kodi tears the player down in `onPlayBackStopped`.

Beyond the durable identity it also builds the richer Tier-1 descriptor and, a
couple of seconds in, the Tier-2 `session.media` details — both companion-only.
"""
import time

import xbmc
import xbmcgui

from . import events
from .events import PlayerEvent

_HOME_WINDOW = 10000
_DRIFT_INTERVAL_S = 10.0
_MEDIA_DELAY_S = 2.0


def _home_property(key):
    return xbmcgui.Window(_HOME_WINDOW).getProperty(key)


def _to_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


class WSPlayer(xbmc.Player):
    """Resolves playback identity/position once per event and fans out to sinks."""

    def __init__(self, state, sinks):
        super().__init__()
        self._state = state
        self._sinks = sinks
        self._started_at = 0.0
        self._last_emit = 0.0
        print("WSPlayer: initialized")

    # -- Kodi event hooks ---------------------------------------------------

    def onAVStarted(self):
        self._guard(self._on_av_started)

    def onPlayBackPaused(self):
        self._guard(lambda: self._on_transition(events.PAUSED, "paused", 0.0))

    def onPlayBackResumed(self):
        self._guard(lambda: self._on_transition(events.RESUMED, "playing", 1.0))

    def onPlayBackSeek(self, time_ms, seek_offset):  # noqa: D401 - Kodi signature
        self._guard(lambda: self._on_seek())

    def onPlayBackStopped(self):
        self._guard(lambda: self._on_end(events.STOPPED))

    def onPlayBackEnded(self):
        self._guard(lambda: self._on_end(events.ENDED))

    # -- handlers -----------------------------------------------------------

    def _on_av_started(self):
        print("WSPlayer: onAVStarted")
        pos, dur = self._read_position()
        durable, descriptor = self._resolve(dur)
        self._state.durable_identity = durable
        self._state.descriptor = descriptor
        self._state.last_pos = pos
        self._state.last_dur = dur
        self._state.active = True
        self._state.media_sent = False
        self._state.phase = "playing"
        self._started_at = time.time()
        self._last_emit = self._started_at
        self._dispatch(
            PlayerEvent(events.AV_STARTED, durable, descriptor, pos, dur, "playing", 1.0)
        )

    def _on_transition(self, kind, phase, rate):
        if not self._state.active:
            return
        print("WSPlayer: {}".format(kind))
        pos, dur = self._read_position()
        self._state.last_pos = pos
        self._state.last_dur = dur
        self._state.phase = phase
        self._last_emit = time.time()
        self._dispatch(
            PlayerEvent(
                kind, self._state.durable_identity, self._state.descriptor, pos, dur, phase, rate
            )
        )

    def _on_seek(self):
        if not self._state.active:
            return
        print("WSPlayer: onPlayBackSeek")
        pos, dur = self._read_position()
        self._state.last_pos = pos
        self._state.last_dur = dur
        phase = self._state.phase if self._state.phase in ("playing", "paused") else "playing"
        rate = 1.0 if phase == "playing" else 0.0
        self._last_emit = time.time()
        self._dispatch(
            PlayerEvent(
                events.SEEK, self._state.durable_identity, self._state.descriptor,
                pos, dur, phase, rate,
            )
        )

    def _on_end(self, kind):
        if not self._state.active and self._state.durable_identity is None:
            return
        print("WSPlayer: {}".format(kind))
        # Player is torn down by now: reuse the last position captured by the
        # active tick. `ENDED` means Kodi reached the end of the playable item,
        # but it is not proof that the full declared runtime was consumed (for
        # example, an early EOF). Never manufacture 100% progress here; the
        # watch-service classifies completion from real position / duration.
        pos = self._state.last_pos
        dur = self._state.last_dur
        self._dispatch(
            PlayerEvent(
                kind, self._state.durable_identity, self._state.descriptor, pos, dur, "idle", 0.0
            )
        )
        self._state.reset()

    # -- periodic work, driven by the service tick loop ---------------------

    def tick(self):
        """Called each adaptive tick: refresh the cached position, emit the 10 s
        drift tick while playing, and send Tier-2 media once it's readable."""
        if not self._state.active:
            return
        self._guard(self._tick)

    def _tick(self):
        now = time.time()
        if self._state.phase == "playing":
            pos, dur = self._read_position()
            if dur > 0:
                self._state.last_pos = pos
                self._state.last_dur = dur
            if now - self._last_emit >= _DRIFT_INTERVAL_S:
                self._last_emit = now
                self._dispatch(
                    PlayerEvent(
                        events.DRIFT, self._state.durable_identity, self._state.descriptor,
                        self._state.last_pos, self._state.last_dur, "playing", 1.0,
                    )
                )
        if not self._state.media_sent and now - self._started_at >= _MEDIA_DELAY_S:
            self._state.media_sent = True
            details = self._read_media_details()
            if details:
                for sink in self._sinks:
                    handler = getattr(sink, "handle_media", None)
                    if handler:
                        handler(details)

    # -- resolution helpers -------------------------------------------------

    def _read_position(self):
        try:
            return float(self.getTime()), float(self.getTotalTime())
        except RuntimeError:
            return self._state.last_pos, self._state.last_dur

    def _resolve(self, duration_s):
        """Return (durable_identity, companion_descriptor). Durable identity is
        byte-identical to the old _identify(); the descriptor is additive."""
        try:
            if not self.isPlayingVideo():
                return None, None
            tag = self.getVideoInfoTag()
        except RuntimeError:
            return None, None

        media_type = tag.getMediaType()

        if media_type == "movie":
            movie_id = _to_int(
                tag.getUniqueID("tmdb") or _home_property("TMDbHelper.Player.TMDb_ID")
            )
            if movie_id is None:
                return None, None
            durable = {"mediaType": "movie", "movieId": movie_id}
            descriptor = {
                "mediaType": "movie",
                "tmdbId": movie_id,
                "durationS": duration_s,
                "resumeFromS": 0,
            }
            self._add_display_fields(descriptor, tag, is_episode=False)
            return durable, descriptor

        if media_type == "episode":
            show_id = _to_int(
                tag.getUniqueID("tvshow.tmdb")
                or _home_property("TMDbHelper.Player.TVShow.TMDb_ID")
            )
            season = tag.getSeason()
            if season is None or season < 0:
                season = _to_int(_home_property("TMDbHelper.Player.Season"))
            episode = tag.getEpisode()
            if episode is None or episode < 0:
                episode = _to_int(_home_property("TMDbHelper.Player.Episode"))
            if show_id is None or season is None or episode is None:
                return None, None
            durable = {
                "mediaType": "episode",
                "showId": show_id,
                "seasonNumber": int(season),
                "episodeNumber": int(episode),
            }
            descriptor = {
                "mediaType": "episode",
                "showTmdbId": show_id,
                "season": int(season),
                "episode": int(episode),
                "displaySeason": int(season),
                "displayEpisode": int(episode),
                "durationS": duration_s,
                "resumeFromS": 0,
            }
            self._add_display_fields(descriptor, tag, is_episode=True)
            return durable, descriptor

        return None, None

    def _add_display_fields(self, descriptor, tag, is_episode):
        try:
            title = tag.getTitle()
            if title:
                descriptor["title"] = title
            if is_episode:
                show_title = tag.getTVShowTitle()
                if show_title:
                    descriptor["showTitle"] = show_title
                ep_tmdb = _to_int(tag.getUniqueID("tmdb"))
                if ep_tmdb is not None:
                    descriptor["tmdbId"] = ep_tmdb
            year = tag.getYear()
            if year:
                descriptor["year"] = int(year)
            imdb = tag.getUniqueID("imdb")
            if imdb:
                descriptor["imdbId"] = imdb
            art = {}
            for key, label in (
                ("poster", "Player.Art(poster)"),
                ("still", "Player.Art(thumb)"),
                ("backdrop", "Player.Art(fanart)"),
            ):
                value = xbmc.getInfoLabel(label)
                if value:
                    art[key] = value
            if art:
                descriptor["art"] = art
        except (RuntimeError, ValueError):
            pass  # display fields are best-effort; identity already resolved

    def _read_media_details(self):
        """Best-effort Tier-2 details from InfoLabels + Player.GetProperties
        (§10). Every field is optional; omit rather than guess."""
        details = {}
        try:
            width = _to_int(xbmc.getInfoLabel("VideoPlayer.VideoResolution"))
            codec = xbmc.getInfoLabel("VideoPlayer.VideoCodec")
            hdr = xbmc.getInfoLabel("VideoPlayer.HdrType")
            acodec = xbmc.getInfoLabel("VideoPlayer.AudioCodec")
            achannels = _to_int(xbmc.getInfoLabel("VideoPlayer.AudioChannels"))
            if codec:
                details["videoCodec"] = codec
            if hdr:
                details["hdrType"] = hdr
            if acodec:
                details["audioCodec"] = acodec
            if achannels:
                details["audioChannels"] = achannels
            # VideoResolution is a height like "2160"; width is derived elsewhere.
            if width:
                details["height"] = width
        except Exception as exc:  # noqa: BLE001 - diagnostics must never break playback
            print("WSPlayer: media details read failed: {}".format(exc))
        return details or None

    # -- dispatch -----------------------------------------------------------

    def _dispatch(self, event):
        for sink in self._sinks:
            try:
                sink.handle(event)
            except Exception as exc:  # noqa: BLE001 - one sink must not break the other
                print("WSPlayer: sink error: {}".format(exc))

    def _guard(self, fn):
        try:
            fn()
        except Exception as exc:  # noqa: BLE001 - a handler error must not kill the loop
            print("WSPlayer: handler error: {}".format(exc))
