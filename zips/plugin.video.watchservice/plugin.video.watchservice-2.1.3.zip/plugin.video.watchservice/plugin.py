# -*- coding: utf-8 -*-
"""READ entry point for plugin.video.watchservice.

Kodi runs this once per navigation to a
``plugin://plugin.video.watchservice/?info=...`` path and fills the calling
container with the ListItems returned here. Dispatch is on the ``info=`` param
(mirroring TMDb Helper / skinvariables). Every route fails to an empty directory,
fast, so a home widget never spins or throws.

    sys.argv[0]  base url, e.g. "plugin://plugin.video.watchservice/"
    sys.argv[1]  numeric request handle (int)
    sys.argv[2]  query string incl. leading "?", e.g. "?info=continue_watching"
"""
import sys
from urllib.parse import parse_qsl, urlencode

import xbmcplugin
import xbmcgui
import xbmcaddon

from resources.lib import mapping
from resources.lib.wsapi import WatchService, log

ADDON = xbmcaddon.Addon()

def _continue_watching(api, _params):
    return mapping.map_continue_watching(api.get_user('continue-watching', _default=[]))


def _next_up(api, _params):
    return mapping.map_next_up(api.get_user('next-up', _default=[]))


def _calendar(api, params):
    return mapping.map_calendar(api.get_user(
        'calendar', _default=[],
        startDate=mapping.offset_to_isodate(params.get('startdate', '0')),
        days=params.get('days', '1')))


def _next_up_for_show(api, params):
    tmdb_id = params.get('tmdb_id')
    if not tmdb_id:
        return []
    return mapping.map_next_up_for_show(
        api.get_user('shows/{}/next-up'.format(tmdb_id), _default=None))


LIST_ROUTES = {
    'continue_watching': _continue_watching,
    'next_up': _next_up,
    'calendar': _calendar,
    'next_up_for_show': _next_up_for_show,
}

# Container content type per route (drives the AF3 view).
CONTENT = {
    'continue_watching': 'videos',
    'next_up': 'episodes',
    'calendar': 'episodes',
    'next_up_for_show': 'episodes',
}


def render(handle, content, built):
    if built:
        xbmcplugin.addDirectoryItems(handle, built, len(built))
    xbmcplugin.setContent(handle, content)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)

def _stream_base():
    return ADDON.getSettingString("stream_server_url").strip().rstrip("/") \
        or "http://localhost:3100"


def _stream_api_key():
    return ADDON.getSettingString("stream_server_api_key").strip()


def _authenticated_stream_url(url):
    """Attach the controlled-client bearer as a Kodi HTTP protocol option."""
    api_key = _stream_api_key()
    if not api_key:
        return url
    return "{}|{}".format(url, urlencode({
        "Authorization": "Bearer {}".format(api_key),
    }))


def _stream_url(
    kind,
    tmdb_id,
    season=None,
    episode=None,
    display_season=None,
    display_episode=None,
    selection_id=None,
    playback_intent_id=None,
):
    """Build the local-server stream URL for a movie or episode."""
    base = _stream_base()
    if kind == "movie":
        url = "{}/Torrents/Movies/{}".format(base, tmdb_id)
    else:
        effective_season = display_season if display_season is not None else season
        effective_episode = display_episode if display_episode is not None else episode
        url = "{}/Torrents/Shows/{}/Season/{}/Episode/{}".format(
            base, tmdb_id, effective_season, effective_episode
        )

    query = {}
    if selection_id:
        query["selection_id"] = selection_id
    if playback_intent_id:
        query["playback_intent_id"] = playback_intent_id
    if query:
        url = "{}?{}".format(url, urlencode(query))
    return url


def dispatch(handle, params):
    info = params.get('info')
    list_route = LIST_ROUTES.get(info)
    if list_route is None:
        if info == 'play':
            kind = "movie" if params.get("kind") == "movie" else "episode"
            stream_url = _stream_url(
                kind,
                params.get("tmdb_id"),
                params.get("season"),
                params.get("episode"),
                params.get("display_season"),
                params.get("display_episode"),
                params.get("selection_id"),
                params.get("playback_intent_id"),
            )
            # Log only the ordinary URL. The playable variant carries a bearer
            # token after Kodi's protocol-option separator and must stay secret.
            log("resolved stream: {}".format(stream_url))
            playback_url = _authenticated_stream_url(stream_url)
            xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(path=playback_url))

            return

        log('unknown info={!r}'.format(info))
        render(handle, 'videos', [])
        return
    render(handle, CONTENT.get(info, 'videos'), list_route(WatchService(), params))


if __name__ == '__main__':
    _handle = int(sys.argv[1])
    _params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
    dispatch(_handle, _params)
