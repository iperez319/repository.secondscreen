# -*- coding: utf-8 -*-
"""Thin HTTP client for the watch-service, plus a small on-disk response cache.

Standard library only (urllib + json). Reads base_url / api_key / user_id /
timeout / cache_ttl from the add-on settings, sends the bearer header, time-boxes
every request, and on any failure returns the caller's fallback (an empty list
for the row endpoints) so the Kodi home screen never blocks or throws.

The cache lives under the add-on profile dir, so the plugin (read) and service
(write) processes share it: after a playback `stop`, service.py calls
``clear_cache()`` so the next home refresh re-fetches and the watched item drops
out of Continue Watching.
"""
import hashlib
import json
import os
import time
from urllib.parse import urlencode, quote
from urllib.request import urlopen, Request
from urllib.error import HTTPError, URLError

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = 'plugin.video.watchservice'


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[{}] {}'.format(ADDON_ID, msg), level)


def _cache_dir():
    path = xbmcvfs.translatePath(
        'special://profile/addon_data/{}/cache/'.format(ADDON_ID))
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def clear_cache():
    """Delete every cached response so the next read goes to the network."""
    try:
        path = _cache_dir()
        _dirs, files = xbmcvfs.listdir(path)
        for name in files:
            xbmcvfs.delete(os.path.join(path, name))
    except Exception as exc:  # noqa: BLE001 - cache is best-effort
        log('cache clear failed: {}'.format(exc), xbmc.LOGWARNING)


class WatchService:
    """Per-process client. Reads settings once on construction."""

    def __init__(self):
        addon = xbmcaddon.Addon(ADDON_ID)
        self.base_url = (addon.getSetting('base_url') or '').rstrip('/')
        self.api_key = addon.getSetting('api_key') or ''
        self.user_id = addon.getSetting('user_id') or ''
        self.timeout = _as_int(addon.getSetting('timeout'), 2)
        self.cache_ttl = _as_int(addon.getSetting('cache_ttl'), 60)

    @property
    def configured(self):
        return bool(self.base_url and self.user_id)

    def _headers(self):
        headers = {'Accept': 'application/json'}
        if self.api_key:
            headers['Authorization'] = 'Bearer {}'.format(self.api_key)
        return headers

    # -- reads --------------------------------------------------------------

    def get_user(self, path, _default=None, **query):
        """GET {base}/users/{user_id}/{path}; return the unwrapped ``data``."""
        rel = 'users/{}/{}'.format(quote(self.user_id), path)
        return self._get(rel, _default=_default, **query)

    def _get(self, rel, _default=None, **query):
        if not self.configured:
            return _default
        pairs = {k: v for k, v in query.items() if v is not None and v != ''}
        url = '{}/{}'.format(self.base_url, rel)
        if pairs:
            url = '{}?{}'.format(url, urlencode(pairs))

        cached = self._cache_read(url)
        if cached is not None:
            return cached

        try:
            request = Request(url, headers=self._headers())
            with urlopen(request, timeout=self.timeout) as response:
                payload = json.loads(response.read().decode('utf-8'))
        except (HTTPError, URLError) as exc:
            log('GET {} failed: {}'.format(url, getattr(exc, 'reason', exc)),
                xbmc.LOGWARNING)
            return _default
        except Exception as exc:  # noqa: BLE001 - JSON/timeout/etc -> empty
            log('GET {} error: {}'.format(url, exc), xbmc.LOGWARNING)
            return _default

        if not isinstance(payload, dict) or not payload.get('success'):
            log('GET {} returned an unsuccessful envelope'.format(url),
                xbmc.LOGWARNING)
            return _default

        data = payload.get('data', _default)
        self._cache_write(url, data)
        return data

    # -- writes -------------------------------------------------------------

    def post(self, path, body, headers=None):
        """POST {base}/{path} with a JSON body. Fire-and-forget; swallow errors."""
        if not self.base_url:
            return False
        url = '{}/{}'.format(self.base_url, path)
        encoded = json.dumps(body).encode('utf-8')
        request_headers = self._headers()
        request_headers['Content-Type'] = 'application/json'
        if headers:
            request_headers.update(headers)
        try:
            request = Request(url, data=encoded, headers=request_headers,
                              method='POST')
            with urlopen(request, timeout=self.timeout) as response:
                response.read()
            return True
        except Exception as exc:  # noqa: BLE001 - write-back is best-effort
            log('POST {} failed: {}'.format(url, exc), xbmc.LOGWARNING)
            return False

    # -- cache --------------------------------------------------------------

    def _cache_path(self, url):
        key = hashlib.sha1(url.encode('utf-8')).hexdigest()
        return os.path.join(_cache_dir(), '{}.json'.format(key))

    def _cache_read(self, url):
        if self.cache_ttl <= 0:
            return None
        path = self._cache_path(url)
        try:
            if not os.path.exists(path):
                return None
            if time.time() - os.path.getmtime(path) > self.cache_ttl:
                return None
            with open(path, 'r', encoding='utf-8') as handle:
                return json.load(handle)
        except Exception:  # noqa: BLE001 - a bad cache entry is just a miss
            return None

    def _cache_write(self, url, data):
        if self.cache_ttl <= 0:
            return
        try:
            with open(self._cache_path(url), 'w', encoding='utf-8') as handle:
                json.dump(data, handle)
        except Exception as exc:  # noqa: BLE001
            log('cache write failed: {}'.format(exc), xbmc.LOGWARNING)


def _as_int(value, fallback):
    try:
        return int(value)
    except (TypeError, ValueError):
        return fallback
