# -*- coding: utf-8 -*-
"""TV overlay for companion-produced contextual actions.

The companion owns action production. This module only renders the currently
active TV action and routes activation back through commands.execute(), so the
same action-window validation is used by phone, Live Activity, and TV.
"""
import math
import time
import uuid

import xbmc
import xbmcaddon
import xbmcgui

from . import commands

ADDON_ID = "plugin.video.watchservice"
XML_FILENAME = "script-watchservice-overlay.xml"
BUTTON_CONTROL_ID = 3012
COUNTDOWN_CONTROL_ID = 3013

ACTION_SELECT_ITEM = 7
ACTION_PLAYER_STOP = 13
ACTION_MOUSE_MOVE = 107
ACTION_MOUSE_LEFT_CLICK = 100
ACTION_MOUSE_DOUBLE_CLICK = 103
ACTION_MOUSE_DRAG = 106


def _as_float(value, default=None):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _action_id(action):
    return action.get("id") if isinstance(action, dict) else None


class _OverlayDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.owner = kwargs.pop("owner", None)
        xbmcgui.WindowXMLDialog.__init__(self, *args, **kwargs)

    def onInit(self):  # pylint: disable=invalid-name
        if self.owner:
            self.owner.on_dialog_init(self)

    def onClick(self, control_id):  # pylint: disable=invalid-name
        if control_id == BUTTON_CONTROL_ID and self.owner:
            self.owner.activate()

    def onAction(self, action):  # pylint: disable=invalid-name
        action_id = action.getId()
        if action_id == ACTION_SELECT_ITEM and self.owner:
            try:
                focused_id = self.getFocusId()
            except RuntimeError:
                focused_id = BUTTON_CONTROL_ID
            if focused_id == BUTTON_CONTROL_ID:
                self.owner.activate()
                return
        if action_id in (
            ACTION_MOUSE_MOVE,
            ACTION_MOUSE_LEFT_CLICK,
            ACTION_MOUSE_DOUBLE_CLICK,
            ACTION_MOUSE_DRAG,
        ):
            return
        if self.owner:
            self.owner.dismiss(user_initiated=(action_id != ACTION_PLAYER_STOP))
        else:
            self.close()


class ActionOverlay(object):
    def __init__(self, state, log, addon_id=ADDON_ID):
        self._state = state
        self._log = log
        self._addon = xbmcaddon.Addon(addon_id)
        self._addon_path = self._addon.getAddonInfo("path")
        self._dialog = None
        self._current_action = None
        self._dismissed_action_id = None
        self._auto_action_id = None
        self._auto_session_id = None
        self._auto_started_at = None
        self._auto_delay = None
        self._auto_cancelled_action_id = None
        self._auto_cancelled_session_id = None
        self._last_position_s = None

    def tick(self):
        if not self._state.active:
            self.close()
            self._last_position_s = None
            return

        position_s = self._position()
        position_jumped = self._position_jumped(position_s)
        action = self._select_action(position_s)
        if not action:
            self._clear_current()
            self._last_position_s = position_s
            return

        action_id = _action_id(action)
        if action_id == self._dismissed_action_id:
            self.close()
            self._last_position_s = position_s
            return

        if not self._current_action or _action_id(self._current_action) != action_id:
            self._show(action)
        else:
            self._current_action = action

        self._tick_auto(action, position_jumped)
        self._update_controls()
        self._last_position_s = position_s

    def close(self):
        self._close_dialog()
        self._current_action = None
        self._clear_auto()

    def dismiss(self, user_initiated=True):
        if user_initiated and self._current_action:
            self._dismissed_action_id = _action_id(self._current_action)
            self._log.debug("overlay dismissed for action {}".format(self._dismissed_action_id))
        self.close()

    def activate(self):
        action = self._current_action
        if not action:
            self.close()
            return

        command_type = self._command_type(action)
        action_id = _action_id(action)
        if not command_type or not action_id:
            self._log.warning("overlay action is not executable: {}".format(action_id))
            self.dismiss(user_initiated=False)
            return

        result = commands.execute(
            {
                "cmdId": "overlay-{}".format(uuid.uuid4().hex),
                "action": {"type": command_type, "actionId": action_id},
            },
            self._state,
            self._log,
        )
        if result.get("ok"):
            self._log.debug("overlay executed action {}".format(action_id))
            self._dismissed_action_id = action_id
        else:
            self._log.warning(
                "overlay action {} failed: {}".format(action_id, result.get("error"))
            )
        self.close()

    def on_dialog_init(self, dialog):
        try:
            dialog.setFocusId(BUTTON_CONTROL_ID)
        except RuntimeError:
            pass
        self._update_controls()

    # -- action selection --------------------------------------------------

    def _select_action(self, position_s):
        candidates = []
        for action in list(self._state.actions or []):
            presentation = action.get("presentation") or {}
            if presentation.get("tv") != "overlay":
                continue
            if not self._in_window(action, position_s):
                continue
            priority = _as_float(presentation.get("priority"), 0.0)
            start = _as_float((action.get("window") or {}).get("startS"), 0.0)
            candidates.append((-priority, start, action))

        if not candidates:
            if self._dismissed_action_id:
                self._dismissed_action_id = None
            return None

        candidates.sort(key=lambda item: (item[0], item[1]))
        selected = candidates[0][2]
        if _action_id(selected) != self._dismissed_action_id:
            self._dismissed_action_id = None
        return selected

    def _in_window(self, action, position_s):
        window = action.get("window") or {}
        start = _as_float(window.get("startS"), 0.0)
        end = _as_float(window.get("endS"), None)
        if position_s < start:
            return False
        if end is not None and position_s > end:
            return False
        return True

    def _position(self):
        try:
            return float(xbmc.Player().getTime())
        except RuntimeError:
            return float(self._state.last_pos or 0.0)

    def _position_jumped(self, position_s):
        if self._last_position_s is None:
            return False
        expected_step = 1.5 if self._state.phase == "playing" else 0.25
        return abs(position_s - self._last_position_s) > expected_step

    # -- rendering ---------------------------------------------------------

    def _show(self, action):
        self._close_dialog()
        self._current_action = action
        self._clear_auto()
        action_id = _action_id(action)
        if (
            self._auto_cancelled_action_id != action_id
            or self._auto_cancelled_session_id != self._state.session_id
        ):
            self._clear_auto_cancel()
        self._dialog = _OverlayDialog(
            XML_FILENAME,
            self._addon_path,
            "default",
            "1080i",
            owner=self,
        )
        self._dialog.show()
        self._log.debug("overlay opened for action {}".format(_action_id(action)))

    def _update_controls(self):
        if not self._dialog or not self._current_action:
            return
        try:
            self._dialog.getControl(BUTTON_CONTROL_ID).setLabel(
                self._current_action.get("label") or "Action"
            )
            self._dialog.getControl(COUNTDOWN_CONTROL_ID).setLabel(self._countdown_label())
        except RuntimeError:
            pass

    def _countdown_label(self):
        if self._auto_started_at is None or self._auto_delay is None:
            return ""
        remaining = max(0.0, self._auto_delay - (time.monotonic() - self._auto_started_at))
        return "{}s".format(int(math.ceil(remaining)))

    def _close_dialog(self):
        if not self._dialog:
            return
        try:
            self._dialog.close()
        except RuntimeError:
            pass
        self._dialog = None

    def _clear_current(self):
        self.close()
        self._dismissed_action_id = None
        self._clear_auto_cancel()

    # -- auto execution ----------------------------------------------------

    def _tick_auto(self, action, position_jumped):
        presentation = action.get("presentation") or {}
        delay = _as_float(presentation.get("autoExecuteAfterS"), None)
        action_id = _action_id(action)
        if delay is None:
            self._clear_auto()
            return

        if (
            self._auto_cancelled_action_id == action_id
            and self._auto_cancelled_session_id == self._state.session_id
        ):
            return

        delay = max(0.0, delay)
        if (
            self._auto_action_id != action_id
            or self._auto_session_id != self._state.session_id
            or self._auto_delay != delay
        ):
            self._auto_action_id = action_id
            self._auto_session_id = self._state.session_id
            self._auto_delay = delay
            self._auto_started_at = time.monotonic()
            self._log.debug("overlay auto countdown started for action {}".format(action_id))

        if position_jumped and self._auto_started_at is not None:
            self._log.debug(
                "overlay auto countdown cancelled by seek for action {}".format(action_id)
            )
            self._auto_cancelled_action_id = action_id
            self._auto_cancelled_session_id = self._state.session_id
            self._clear_auto()
            return

        if time.monotonic() - self._auto_started_at >= delay:
            self._log.debug("overlay auto countdown completed for action {}".format(action_id))
            self.activate()

    def _clear_auto(self):
        self._auto_action_id = None
        self._auto_session_id = None
        self._auto_started_at = None
        self._auto_delay = None

    def _clear_auto_cancel(self):
        self._auto_cancelled_action_id = None
        self._auto_cancelled_session_id = None

    # -- execution ---------------------------------------------------------

    def _command_type(self, action):
        execute = action.get("execute") or {}
        execute_type = execute.get("type")
        if execute_type == "seek":
            return "skip"
        if execute_type == "play_next":
            return "play_next"
        return None
