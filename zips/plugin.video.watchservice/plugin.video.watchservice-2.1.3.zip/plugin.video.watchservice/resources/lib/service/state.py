# -*- coding: utf-8 -*-
"""Session-local state, centralized so the ~40-field reset problem that plagues
service.nextonlibrary can't happen — everything ephemeral lives here and dies in
one `reset()` on stop (design §8.2)."""
from collections import OrderedDict


class SessionState(object):
    def __init__(self):
        self.reset()
        # Survives across sessions (per-connection command dedupe is companion-
        # side; this LRU guards re-execution across retries — protocol §5).
        self._executed = OrderedDict()

    def reset(self):
        #: Durable identity captured while the player was alive, replayed on stop
        #: (getVideoInfoTag() raises once the player is torn down).
        self.durable_identity = None
        #: Tier-1 companion descriptor for the current media.
        self.descriptor = None
        #: Last good position/duration, cached on live events for stop replay.
        self.last_pos = 0.0
        self.last_dur = 0.0
        #: True between AV start and stop.
        self.active = False
        #: True once the Tier-2 session.media has been sent for this session.
        self.media_sent = False
        self.phase = "idle"
        #: Current contextual actions from companion `session.segments`.
        self.session_id = None
        self.actions = []

    # -- command dedupe LRU (protocol §5) -----------------------------------

    def seen_command(self, cmd_id):
        return cmd_id in self._executed

    def record_command(self, cmd_id, result):
        self._executed[cmd_id] = result
        while len(self._executed) > 50:
            self._executed.popitem(last=False)

    def command_result(self, cmd_id):
        return self._executed.get(cmd_id)

    # -- contextual actions -------------------------------------------------

    def set_actions(self, session_id, actions):
        self.session_id = session_id
        self.actions = list(actions or [])

    def action_by_id(self, action_id):
        for action in self.actions:
            if action.get("id") == action_id:
                return action
        return None
