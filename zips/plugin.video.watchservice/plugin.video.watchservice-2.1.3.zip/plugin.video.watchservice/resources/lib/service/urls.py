# -*- coding: utf-8 -*-
"""URL derivation shared by the Kodi companion link and its unit tests."""

try:
    from urllib.parse import urlsplit, urlunsplit
except ImportError:  # pragma: no cover - Python 2 compatibility for older Kodi
    from urlparse import urlsplit, urlunsplit


def companion_websocket_url(raw):
    """Derive /ws from a scheme-bearing Companion base URL.

    HTTP is the LAN/development form and maps to WS. HTTPS is the externally
    hosted production form and maps to WSS. Direct WS/WSS input and a bare host
    remain accepted for compatibility with existing addon settings.
    """
    value = (raw or "").strip()
    if not value:
        raise ValueError("Companion URL is empty")
    if "://" not in value:
        value = "http://" + value

    parsed = urlsplit(value)
    scheme = parsed.scheme.lower()
    websocket_scheme = {
        "http": "ws",
        "https": "wss",
        "ws": "ws",
        "wss": "wss",
    }.get(scheme)
    if websocket_scheme is None or not parsed.netloc:
        raise ValueError("Companion URL must use http:// or https://")
    if parsed.path not in ("", "/"):
        raise ValueError("Companion base URL must not include a path")

    return urlunsplit((websocket_scheme, parsed.netloc, "/ws", "", ""))
