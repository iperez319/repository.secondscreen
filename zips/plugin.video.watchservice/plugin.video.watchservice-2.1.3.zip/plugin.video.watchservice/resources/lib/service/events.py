# -*- coding: utf-8 -*-
"""The normalized playback event that flows monitor → sinks.

`player_monitor` resolves identity and position exactly ONCE per Kodi callback
and packs the result here; the durable and companion sinks then consume the same
immutable snapshot, so the two can never disagree about identity or final
position (the drift risk that killed the "second addon" option — design §8.1).
"""

# Event kinds, named after their Kodi triggers so each sink can filter cleanly.
AV_STARTED = "av_started"
PAUSED = "paused"
RESUMED = "resumed"
SEEK = "seek"
STOPPED = "stopped"
ENDED = "ended"
DRIFT = "drift"  # the 10 s while-playing tick (companion only; never durable)


class PlayerEvent(object):
    __slots__ = (
        "kind",
        "durable_identity",
        "descriptor",
        "position_s",
        "duration_s",
        "phase",
        "rate",
    )

    def __init__(self, kind, durable_identity, descriptor, position_s, duration_s, phase, rate):
        #: The exact dict today's WSPlayer._identify() returns — the sacred,
        #: byte-identical durable-path identity (or None for unidentified media).
        self.durable_identity = durable_identity
        #: The richer Tier-1 SessionDescriptor for the companion (or None).
        self.descriptor = descriptor
        self.kind = kind
        self.position_s = position_s
        self.duration_s = duration_s
        self.phase = phase  # "playing" | "paused" | "buffering"
        self.rate = rate

    @property
    def player_state(self):
        """The anchored-position PlayerState payload for the companion (§9.1).
        The companion re-stamps `anchorTs` on receipt, so an approximate local
        clock is fine here."""
        import time

        return {
            "phase": self.phase,
            "positionS": max(0.0, self.position_s),
            "rate": self.rate,
            "anchorTs": int(time.time() * 1000),
        }
