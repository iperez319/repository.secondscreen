# The Kodi-side agent for the second-screen backend: one player monitor feeding
# two sinks (durable watch-service HTTP, live companion WebSocket). See
# ../../../addon.xml and kodi/docs/second-screen/01-design.md §8.2.
