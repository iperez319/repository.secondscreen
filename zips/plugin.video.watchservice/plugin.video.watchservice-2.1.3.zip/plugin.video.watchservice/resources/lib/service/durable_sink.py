# -*- coding: utf-8 -*-
"""The durable playback path from Kodi to the watch-service.

It reacts to the original subset of events (AV-start and pause → `progress`;
stop and end → `stop`), adds the explicit Kodi client discriminator, sends the
same Idempotency-Key on stop, and clears the read cache on stop.
"""
import hashlib
import json

from resources.lib.wsapi import WatchService, clear_cache

from . import events


class DurableSink(object):
    """Posts playback progress/stop to the watch-service (unchanged semantics)."""

    def __init__(self, service_factory=WatchService):
        # Injectable for tests; defaults to the real per-call client.
        self._service_factory = service_factory

    def handle(self, event):
        if event.kind in (events.AV_STARTED, events.PAUSED):
            self._post("progress", event)
        elif event.kind in (events.STOPPED, events.ENDED):
            self._post("stop", event)
        # RESUMED / SEEK / DRIFT are companion-only; the durable path ignored
        # them before and must keep ignoring them (byte-identical behavior).

    def _post(self, event_type, event):
        body = dict(event.durable_identity) if event.durable_identity else None
        if not body:
            print("WSPlayer: no identity for event '{}' -> ignoring".format(event_type))
            return  # not a tmdb-identified item -> ignore
        if event.duration_s <= 0:
            return

        print("WSPlayer: posting event '{}'".format(event_type))
        body["clientType"] = "kodi"
        body["type"] = "stop" if event_type == "stop" else "progress"
        body["positionSeconds"] = max(0.0, event.position_s)
        body["durationSeconds"] = event.duration_s

        headers = {"Idempotency-Key": _idempotency_key(body)} if event_type == "stop" else None
        self._service_factory().post("events/playback", body, headers)
        if event_type == "stop":
            clear_cache()  # next home refresh reflects the new watched state


def _idempotency_key(body):
    """Stable key over the event's identity so a retried stop records once."""
    identity = {
        k: body.get(k)
        for k in (
            "mediaType",
            "showId",
            "seasonNumber",
            "episodeNumber",
            "movieId",
            "positionSeconds",
        )
    }
    blob = json.dumps(identity, sort_keys=True)
    return hashlib.sha1(blob.encode("utf-8")).hexdigest()
