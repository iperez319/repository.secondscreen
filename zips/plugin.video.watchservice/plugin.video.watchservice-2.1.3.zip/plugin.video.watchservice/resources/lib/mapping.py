# -*- coding: utf-8 -*-
"""Map watch-service JSON items to Kodi ``xbmcgui.ListItem`` objects.

Each ``map_*`` returns a list of ``(url, ListItem, isFolder)`` tuples ready for
``xbmcplugin.addDirectoryItems``. ``url`` is always a TMDb Helper ``info=play``
path (Arctic Fuse 3 delegates playback to TMDb Helper), so clicking a tile plays
through the configured players.

Field casing is per the watch-service API (verified against source):
  * continue-watching / next-up-for-show / playback : camelCase
  * next-up : snake_case, EXCEPT ``airDate`` (camelCase)
  * calendar : nested ``show.ids.tmdb`` / ``episode.season`` / ``first_aired``
Art fields (``poster`` / ``fanart`` / ``thumb``) are full URLs added server-side.
"""
import datetime

import xbmcgui

_HELPER_PLAY = 'plugin://plugin.video.themoviedb.helper/?info=play'


# -- play paths -------------------------------------------------------------

def tv_play_path(show_id, season, episode):
    return '{}&tmdb_type=tv&tmdb_id={}&season={}&episode={}'.format(
        _HELPER_PLAY, show_id, season, episode)


def movie_play_path(movie_id):
    return '{}&tmdb_type=movie&tmdb_id={}'.format(_HELPER_PLAY, movie_id)


# -- public mappers ---------------------------------------------------------

def map_continue_watching(items):
    out = []
    for item in items or []:
        built = (_cw_movie(item) if item.get('mediaType') == 'movie'
                 else _cw_episode(item))
        if built:
            out.append(built)
    return out


def map_next_up(items):
    out = []
    for item in items or []:
        built = _next_up_item(item)
        if built:
            out.append(built)
    return out


def map_calendar(items):
    out = []
    for item in items or []:
        built = _calendar_item(item)
        if built:
            out.append(built)
    return out


def map_next_up_for_show(episode):
    """The OSD 'Up Next' card: a single enriched episode (or nothing)."""
    if not episode:
        return []
    built = _next_up_for_show_item(episode)
    return [built] if built else []


# -- episode/movie builders -------------------------------------------------

def _cw_episode(it):
    show_id, season, episode = it.get('showId'), it.get('seasonNumber'), it.get('episodeNumber')
    if show_id is None or season is None or episode is None:
        return None
    li = xbmcgui.ListItem(label=it.get('episodeTitle') or it.get('showTitle') or '')
    tag = li.getVideoInfoTag()
    tag.setMediaType('episode')
    tag.setTvShowTitle(it.get('showTitle') or '')
    tag.setTitle(it.get('episodeTitle') or '')
    tag.setSeason(int(season))
    tag.setEpisode(int(episode))
    _set_episode_ids(tag, show_id, it.get('imdbId'))
    _apply_progress(li, tag, it.get('progressSeconds'), it.get('durationSeconds'))
    _apply_art(li, it)
    li.setProperty('IsPlayable', 'true')
    return tv_play_path(show_id, season, episode), li, False


def _cw_movie(it):
    movie_id = it.get('movieId')
    if movie_id is None:
        return None
    li = xbmcgui.ListItem(label=it.get('movieTitle') or '')
    tag = li.getVideoInfoTag()
    tag.setMediaType('movie')
    tag.setTitle(it.get('movieTitle') or '')
    tag.setUniqueIDs({'tmdb': str(movie_id)}, 'tmdb')
    _apply_progress(li, tag, it.get('progressSeconds'), it.get('durationSeconds'))
    _apply_art(li, it)
    li.setProperty('IsPlayable', 'true')
    return movie_play_path(movie_id), li, False


def _next_up_item(it):
    show_id, season, episode = it.get('show_id'), it.get('season_number'), it.get('episode_number')
    if show_id is None or season is None or episode is None:
        return None
    li = xbmcgui.ListItem(label=it.get('episode_title') or it.get('show_title') or '')
    tag = li.getVideoInfoTag()
    tag.setMediaType('episode')
    tag.setTvShowTitle(it.get('show_title') or '')
    tag.setTitle(it.get('episode_title') or '')
    tag.setSeason(int(season))
    tag.setEpisode(int(episode))
    if it.get('episode_overview'):
        tag.setPlot(it['episode_overview'])
    _set_duration(tag, it.get('runtime_minutes'))
    _set_air_dates(tag, it.get('airDate'))
    _set_episode_ids(tag, show_id, it.get('imdb_id'))
    # No WatchedProgress (next-up is unwatched -> no ring). Optional segmented
    # season-progress bar via tier 1 of Defs_PercentPlayed.
    _apply_season_percent(li, it.get('season_watched_count'), it.get('season_aired_count'))
    _apply_art(li, it)
    li.setProperty('IsPlayable', 'true')
    return tv_play_path(show_id, season, episode), li, False


def _calendar_item(it):
    show = it.get('show') or {}
    ids = show.get('ids') or {}
    ep = it.get('episode') or {}
    show_id, season, episode = ids.get('tmdb'), ep.get('season'), ep.get('number')
    if show_id is None or season is None or episode is None:
        return None
    li = xbmcgui.ListItem(label=ep.get('title') or show.get('title') or '')
    tag = li.getVideoInfoTag()
    tag.setMediaType('episode')
    tag.setTvShowTitle(show.get('title') or '')
    tag.setTitle(ep.get('title') or '')
    tag.setSeason(int(season))
    tag.setEpisode(int(episode))
    _set_episode_ids(tag, show_id, ids.get('imdb'))
    first_aired = it.get('first_aired')
    if first_aired:
        _set_air_dates(tag, first_aired)
        # AF3's Next-Aired layout reads these ListItem properties (see
        # Includes_NextAired.xml).
        li.setProperty('air_date', _date_only(first_aired))
        li.setProperty('air_date_short', _short_date(first_aired))
        li.setProperty('widget', _weekday(first_aired))
    _apply_art(li, it)
    li.setProperty('IsPlayable', 'true')
    return tv_play_path(show_id, season, episode), li, False


def _next_up_for_show_item(ep):
    show_id, season, episode = ep.get('showId'), ep.get('seasonNumber'), ep.get('episodeNumber')
    if show_id is None or season is None or episode is None:
        return None
    li = xbmcgui.ListItem(label=ep.get('episodeTitle') or ep.get('showTitle') or '')
    tag = li.getVideoInfoTag()
    tag.setMediaType('episode')
    tag.setTvShowTitle(ep.get('showTitle') or '')
    tag.setTitle(ep.get('episodeTitle') or '')
    tag.setSeason(int(season))
    tag.setEpisode(int(episode))
    if ep.get('overview'):
        tag.setPlot(ep['overview'])
    _set_duration(tag, ep.get('runtimeMinutes'))
    _set_episode_ids(tag, show_id, ep.get('imdbId'))
    _apply_art(li, ep)
    li.setProperty('IsPlayable', 'true')
    return tv_play_path(show_id, season, episode), li, False


# -- shared field helpers ---------------------------------------------------

def _set_episode_ids(tag, show_id, imdb):
    # 'tvshow.tmdb' is what TMDb Helper's player monitor reads for episodes (to
    # populate TMDbHelper.Player.TVShow.TMDb_ID); 'tmdb' drives baseitem.json art.
    ids = {'tmdb': str(show_id), 'tvshow.tmdb': str(show_id)}
    if imdb:
        ids['imdb'] = imdb
    tag.setUniqueIDs(ids, 'tmdb')


def _apply_progress(li, tag, pos, dur):
    try:
        pos, dur = float(pos), float(dur)
    except (TypeError, ValueError):
        return
    if pos > 0 and dur > 0:
        pct = max(1, min(99, int(round(pos / dur * 100))))
        li.setProperty('WatchedProgress', str(pct))  # lights AF3's ring
        tag.setResumePoint(pos, dur)                  # native Resume from...


def _apply_season_percent(li, watched, aired):
    try:
        aired = int(aired)
        watched = int(watched or 0)
    except (TypeError, ValueError):
        return
    if aired > 0:
        pct = int(round(watched / aired * 100))
        if 0 < pct < 100:
            li.setProperty('WatchedEpisodePercent', str(pct))


def _apply_art(li, it):
    art = {key: it[key] for key in ('thumb', 'poster', 'fanart') if it.get(key)}
    if art:
        li.setArt(art)


def _set_duration(tag, runtime_minutes):
    if not runtime_minutes:
        return
    try:
        tag.setDuration(int(runtime_minutes) * 60)
    except (TypeError, ValueError):
        pass


def _set_air_dates(tag, iso):
    date = _date_only(iso)
    if date:
        tag.setFirstAired(date)
        tag.setPremiered(date)


# -- date formatting --------------------------------------------------------

def offset_to_isodate(offset):
    """Turn a relative day offset (e.g. '-1', '0', '1') into an absolute ISO
    date for the watch-service `startDate` query (the skin passes offsets, the
    service wants an absolute date)."""
    try:
        days = int(offset)
    except (TypeError, ValueError):
        days = 0
    return (datetime.date.today() + datetime.timedelta(days=days)).isoformat()


def _date_only(iso):
    return str(iso)[:10] if iso else ''


def _parse_iso(iso):
    if not iso:
        return None
    text = str(iso).replace('Z', '+00:00')
    try:
        return datetime.datetime.fromisoformat(text)
    except ValueError:
        try:
            return datetime.datetime.strptime(text[:10], '%Y-%m-%d')
        except ValueError:
            return None


def _short_date(iso):
    parsed = _parse_iso(iso)
    return parsed.strftime('%a %d') if parsed else ''


def _weekday(iso):
    parsed = _parse_iso(iso)
    return parsed.strftime('%A') if parsed else ''
