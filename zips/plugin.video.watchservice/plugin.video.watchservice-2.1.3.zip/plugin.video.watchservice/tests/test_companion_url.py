# -*- coding: utf-8 -*-
"""Companion base URL contract tests runnable outside Kodi."""
import os
import sys
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


from resources.lib.service.urls import companion_websocket_url  # noqa: E402


class CompanionURLTests(unittest.TestCase):
    def test_lan_http_derives_ws(self):
        self.assertEqual(
            companion_websocket_url("http://192.168.1.10:3200/"),
            "ws://192.168.1.10:3200/ws",
        )

    def test_production_https_derives_wss(self):
        self.assertEqual(
            companion_websocket_url("https://companion.example.com"),
            "wss://companion.example.com/ws",
        )

    def test_query_and_fragment_do_not_reach_upgrade_url(self):
        self.assertEqual(
            companion_websocket_url("https://companion.example.com/?ignored=true#fragment"),
            "wss://companion.example.com/ws",
        )

    def test_legacy_bare_host_and_websocket_schemes_remain_compatible(self):
        self.assertEqual(
            companion_websocket_url("companion.local:3200"),
            "ws://companion.local:3200/ws",
        )
        self.assertEqual(
            companion_websocket_url("wss://companion.example.com"),
            "wss://companion.example.com/ws",
        )

    def test_base_path_is_rejected(self):
        with self.assertRaises(ValueError):
            companion_websocket_url("https://companion.example.com/base")


if __name__ == "__main__":
    unittest.main()
