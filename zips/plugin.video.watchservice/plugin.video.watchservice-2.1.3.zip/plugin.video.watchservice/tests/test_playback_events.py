# -*- coding: utf-8 -*-
"""Playback event contract tests runnable outside Kodi with stdlib unittest."""
import os
import sys
import types
import unittest


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


class _KodiPlayer(object):
    def __init__(self):
        pass


xbmc = types.ModuleType("xbmc")
xbmc.Player = _KodiPlayer
xbmc.LOGINFO = 1
xbmc.LOGWARNING = 2
xbmc.log = lambda *_args, **_kwargs: None
sys.modules.setdefault("xbmc", xbmc)

xbmcgui = types.ModuleType("xbmcgui")
xbmcgui.Window = lambda _window_id: None
sys.modules.setdefault("xbmcgui", xbmcgui)

xbmcaddon = types.ModuleType("xbmcaddon")
xbmcaddon.Addon = lambda _addon_id: None
sys.modules.setdefault("xbmcaddon", xbmcaddon)

xbmcvfs = types.ModuleType("xbmcvfs")
xbmcvfs.translatePath = lambda path: path
xbmcvfs.exists = lambda _path: True
xbmcvfs.mkdirs = lambda _path: None
xbmcvfs.listdir = lambda _path: ([], [])
xbmcvfs.delete = lambda _path: None
sys.modules.setdefault("xbmcvfs", xbmcvfs)

from resources.lib.service import events  # noqa: E402
from resources.lib.service.durable_sink import DurableSink  # noqa: E402
from resources.lib.service.player_monitor import WSPlayer  # noqa: E402
from resources.lib.service.state import SessionState  # noqa: E402


class _CaptureSink(object):
    def __init__(self):
        self.events = []

    def handle(self, event):
        self.events.append(event)


class _CaptureService(object):
    def __init__(self):
        self.requests = []

    def post(self, path, body, headers=None):
        self.requests.append((path, body, headers))


class PlaybackEventTests(unittest.TestCase):
    def test_seek_uses_callback_target_when_get_time_is_stale(self):
        state = SessionState()
        state.active = True
        state.phase = "playing"
        state.last_pos = 120.0
        state.last_dur = 1800.0
        capture = _CaptureSink()
        player = WSPlayer(state, [capture])
        player._read_position = lambda: (120.0, 1800.0)

        player._on_seek(900000)

        self.assertEqual(len(capture.events), 1)
        self.assertEqual(capture.events[0].kind, events.SEEK)
        self.assertEqual(capture.events[0].position_s, 900.0)
        self.assertEqual(capture.events[0].phase, "playing")
        self.assertEqual(capture.events[0].rate, 1.0)

    def test_seek_while_paused_keeps_paused_anchor(self):
        state = SessionState()
        state.active = True
        state.phase = "paused"
        state.last_pos = 120.0
        state.last_dur = 1800.0
        capture = _CaptureSink()
        player = WSPlayer(state, [capture])
        player._read_position = lambda: (120.0, 1800.0)

        player._on_seek(600000)

        self.assertEqual(capture.events[0].position_s, 600.0)
        self.assertEqual(capture.events[0].phase, "paused")
        self.assertEqual(capture.events[0].rate, 0.0)

    def test_ended_preserves_cached_position_instead_of_forcing_duration(self):
        state = SessionState()
        state.active = True
        state.durable_identity = {"mediaType": "movie", "movieId": 550}
        state.descriptor = {"mediaType": "movie", "tmdbId": 550}
        state.last_pos = 600.0
        state.last_dur = 1800.0
        capture = _CaptureSink()
        player = WSPlayer(state, [capture])

        player._on_end(events.ENDED)

        self.assertEqual(len(capture.events), 1)
        self.assertEqual(capture.events[0].position_s, 600.0)
        self.assertEqual(capture.events[0].duration_s, 1800.0)
        self.assertFalse(state.active)

    def test_durable_sink_identifies_kodi_and_forwards_real_position(self):
        service = _CaptureService()
        sink = DurableSink(service_factory=lambda: service)
        event = events.PlayerEvent(
            events.ENDED,
            {"mediaType": "movie", "movieId": 550},
            None,
            600.0,
            1800.0,
            "idle",
            0.0,
        )

        sink.handle(event)

        self.assertEqual(len(service.requests), 1)
        path, body, headers = service.requests[0]
        self.assertEqual(path, "events/playback")
        self.assertEqual(body["clientType"], "kodi")
        self.assertEqual(body["positionSeconds"], 600.0)
        self.assertEqual(body["durationSeconds"], 1800.0)
        self.assertIn("Idempotency-Key", headers)


if __name__ == "__main__":
    unittest.main()
