import importlib
import sys
import types
import unittest


class _Player(object):
    def __init__(self):
        self.played = []
        self.playing = True
        self.pause_count = 0

    def play(self, url):
        self.played.append(url)

    def getTime(self):
        return 10.0

    def isPlaying(self):
        return self.playing

    def pause(self):
        self.pause_count += 1


class _State(object):
    active = False
    phase = "playing"
    last_pos = 0
    last_dur = 0

    def seen_command(self, _cmd_id):
        return False

    def record_command(self, _cmd_id, _result):
        pass

    def action_by_id(self, _action_id):
        return None


class PlaybackIntentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.player = _Player()
        xbmc = types.ModuleType("xbmc")
        xbmc.Player = lambda: cls.player
        xbmc.executeJSONRPC = lambda _payload: '{"result": {}}'
        sys.modules["xbmc"] = xbmc
        cls.commands = importlib.import_module("resources.lib.service.commands")

    def setUp(self):
        self.player.played[:] = []
        self.player.playing = True
        self.player.pause_count = 0

    def test_set_playback_state_is_idempotent(self):
        state = _State()
        state.active = True
        state.phase = "playing"
        log = types.SimpleNamespace(warning=lambda *_args: None)

        paused = self.commands.execute({
            "cmdId": "pause-one",
            "action": {"type": "set_playback_state", "state": "paused"},
        }, state, log)
        paused_again = self.commands.execute({
            "cmdId": "pause-two",
            "action": {"type": "set_playback_state", "state": "paused"},
        }, state, log)
        resumed = self.commands.execute({
            "cmdId": "resume-one",
            "action": {"type": "set_playback_state", "state": "playing"},
        }, state, log)
        resumed_again = self.commands.execute({
            "cmdId": "resume-two",
            "action": {"type": "set_playback_state", "state": "playing"},
        }, state, log)

        self.assertTrue(paused["ok"])
        self.assertEqual(paused["resultingState"]["phase"], "paused")
        self.assertTrue(paused_again["ok"])
        self.assertTrue(resumed["ok"])
        self.assertEqual(resumed["resultingState"]["phase"], "playing")
        self.assertTrue(resumed_again["ok"])
        self.assertEqual(self.player.pause_count, 2)

    def test_set_playback_state_handles_buffering_and_no_player(self):
        state = _State()
        state.active = True
        state.phase = "buffering"
        log = types.SimpleNamespace(warning=lambda *_args: None)

        paused = self.commands.execute({
            "cmdId": "pause-buffering",
            "action": {"type": "set_playback_state", "state": "paused"},
        }, state, log)
        self.assertTrue(paused["ok"])
        self.assertEqual(state.phase, "paused")
        self.assertEqual(self.player.pause_count, 1)

        self.player.playing = False
        missing = self.commands.execute({
            "cmdId": "no-player",
            "action": {"type": "set_playback_state", "state": "playing"},
        }, state, log)
        self.assertEqual(missing["error"], "no_active_player")

    def test_set_playback_state_reuses_cached_result_for_duplicate_command_id(self):
        class DedupeState(_State):
            def __init__(self):
                self.active = True
                self.phase = "playing"
                self.last_pos = 0
                self.last_dur = 0
                self.results = {}

            def seen_command(self, cmd_id):
                return cmd_id in self.results

            def record_command(self, cmd_id, result):
                self.results[cmd_id] = result

            def command_result(self, cmd_id):
                return self.results[cmd_id]

        state = DedupeState()
        payload = {
            "cmdId": "same-command",
            "action": {"type": "set_playback_state", "state": "paused"},
        }
        log = types.SimpleNamespace(warning=lambda *_args: None)

        first = self.commands.execute(payload, state, log)
        duplicate = self.commands.execute(payload, state, log)

        self.assertEqual(duplicate, first)
        self.assertEqual(self.player.pause_count, 1)

    def test_safe_append_preserves_tmdb_helper_identity_and_parameters(self):
        intent_id = "9d178f99-975b-43d8-a48b-928b50d302d4"
        original = "plugin://plugin.video.themoviedb.helper/?info=play&tmdb_type=tv&tmdb_id=10&season=1&episode=2"
        result = self.commands._plugin_url_with_intent(original, intent_id)
        self.assertIn("tmdb_id=10", result)
        self.assertIn("playback_intent_id=" + intent_id, result)
        self.assertTrue(result.startswith("plugin://plugin.video.themoviedb.helper/?"))

    def test_rejects_bad_uuid_and_lookalike_plugin_urls(self):
        valid = "9d178f99-975b-43d8-a48b-928b50d302d4"
        self.assertIsNone(self.commands._plugin_url_with_intent(
            "plugin://plugin.video.themoviedb.helper.evil/?info=play", valid))
        self.assertIsNone(self.commands._plugin_url_with_intent(
            "plugin://plugin.video.themoviedb.helper/?info=play", "bad"))

    def test_play_relay_appends_intent_before_execution(self):
        intent_id = "9d178f99-975b-43d8-a48b-928b50d302d4"
        result = self.commands.execute({
            "cmdId": "one",
            "action": {
                "type": "play",
                "pluginUrl": "plugin://plugin.video.themoviedb.helper/?info=play&tmdb_id=10",
                "playbackIntentId": intent_id,
            },
        }, _State(), types.SimpleNamespace(warning=lambda *_args: None))
        self.assertTrue(result["ok"])
        self.assertIn("playback_intent_id=" + intent_id, self.player.played[-1])

    def test_watchservice_stream_url_encodes_both_capabilities(self):
        xbmcplugin = types.ModuleType("xbmcplugin")
        xbmcgui = types.ModuleType("xbmcgui")
        xbmcaddon = types.ModuleType("xbmcaddon")
        settings = {
            "stream_server_url": "http://stream.local",
            "stream_server_api_key": "stream secret/+",
        }
        xbmcaddon.Addon = lambda: types.SimpleNamespace(
            getSettingString=lambda key: settings.get(key, ""))
        sys.modules.update({"xbmcplugin": xbmcplugin, "xbmcgui": xbmcgui, "xbmcaddon": xbmcaddon})
        wsapi = types.ModuleType("resources.lib.wsapi")
        wsapi.WatchService = object
        wsapi.log = lambda *_args: None
        sys.modules["resources.lib.wsapi"] = wsapi
        plugin = importlib.import_module("plugin")
        url = plugin._stream_url(
            "episode", "10", "1", "2", selection_id="a b",
            playback_intent_id="9d178f99-975b-43d8-a48b-928b50d302d4",
        )
        self.assertIn("selection_id=a+b", url)
        self.assertIn("playback_intent_id=9d178f99-975b-43d8-a48b-928b50d302d4", url)

        authenticated = plugin._authenticated_stream_url(url)
        self.assertEqual(authenticated.split("|", 1)[0], url)
        self.assertIn("Authorization=Bearer+stream+secret%2F%2B", authenticated)

        settings["stream_server_api_key"] = ""
        self.assertEqual(plugin._authenticated_stream_url(url), url)

    def test_play_next_validates_window_and_propagates_intent(self):
        intent_id = "9d178f99-975b-43d8-a48b-928b50d302d4"

        class State(_State):
            def action_by_id(self, action_id):
                if action_id != "next":
                    return None
                return {
                    "window": {"startS": 8, "endS": 12},
                    "execute": {
                        "type": "play_next",
                        "pluginUrl": "plugin://plugin.video.themoviedb.helper/?info=play&tmdb_id=10&playback_intent_id=old",
                    },
                }

        result = self.commands.execute({
            "cmdId": "next-command",
            "action": {
                "type": "play_next",
                "actionId": "next",
                "playbackIntentId": intent_id,
            },
        }, State(), types.SimpleNamespace(warning=lambda *_args: None))

        self.assertTrue(result["ok"])
        self.assertIn("playback_intent_id=" + intent_id, self.player.played[-1])
        self.assertNotIn("playback_intent_id=old", self.player.played[-1])

    def test_play_next_rejects_unknown_action_and_malformed_intent(self):
        before = list(self.player.played)
        unknown = self.commands.execute({
            "cmdId": "unknown",
            "action": {"type": "play_next", "actionId": "missing"},
        }, _State(), types.SimpleNamespace(warning=lambda *_args: None))
        self.assertEqual(unknown["error"], "unknown_action")

        class State(_State):
            def action_by_id(self, _action_id):
                return {
                    "window": {"startS": 0, "endS": 20},
                    "execute": {
                        "type": "play_next",
                        "pluginUrl": "plugin://plugin.video.themoviedb.helper/?info=play&tmdb_id=10",
                    },
                }

        malformed = self.commands.execute({
            "cmdId": "malformed",
            "action": {
                "type": "play_next", "actionId": "next",
                "playbackIntentId": "not-a-uuid",
            },
        }, State(), types.SimpleNamespace(warning=lambda *_args: None))
        self.assertEqual(malformed["error"], "invalid_command")
        self.assertEqual(self.player.played, before)


if __name__ == "__main__":
    unittest.main()
