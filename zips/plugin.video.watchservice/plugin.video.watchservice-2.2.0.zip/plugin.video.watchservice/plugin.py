# -*- coding: utf-8 -*-
"""READ entry point for plugin.video.watchservice.

Kodi runs this once per navigation to a
``plugin://plugin.video.watchservice/?info=...`` path and fills the calling
container with the ListItems returned here. Dispatch is on the ``info=`` param
(mirroring TMDb Helper / skinvariables). Every route fails to an empty directory,
fast, so a home widget never spins or throws.

``info=play`` is TMDb Helper's player hook. It resolves the final stream URL via
the stream server's JSON resolve API before calling setResolvedUrl (see
resources/lib/resolver.py), and fails with a notification otherwise.

    sys.argv[0]  base url, e.g. "plugin://plugin.video.watchservice/"
    sys.argv[1]  numeric request handle (int)
    sys.argv[2]  query string incl. leading "?", e.g. "?info=continue_watching"
"""
import sys
import uuid
from urllib.parse import parse_qsl, urlparse

import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon

from resources.lib import mapping, resolver
from resources.lib.wsapi import WatchService, log

ADDON = xbmcaddon.Addon()

def _continue_watching(api, _params):
    return mapping.map_continue_watching(api.get_user('continue-watching', _default=[]))


def _next_up(api, _params):
    return mapping.map_next_up(api.get_user('next-up', _default=[]))


def _calendar(api, params):
    return mapping.map_calendar(api.get_user(
        'calendar', _default=[],
        startDate=mapping.offset_to_isodate(params.get('startdate', '0')),
        days=params.get('days', '1')))


def _next_up_for_show(api, params):
    tmdb_id = params.get('tmdb_id')
    if not tmdb_id:
        return []
    return mapping.map_next_up_for_show(
        api.get_user('shows/{}/next-up'.format(tmdb_id), _default=None))


LIST_ROUTES = {
    'continue_watching': _continue_watching,
    'next_up': _next_up,
    'calendar': _calendar,
    'next_up_for_show': _next_up_for_show,
}

# Container content type per route (drives the AF3 view).
CONTENT = {
    'continue_watching': 'videos',
    'next_up': 'episodes',
    'calendar': 'episodes',
    'next_up_for_show': 'episodes',
}


def render(handle, content, built):
    if built:
        xbmcplugin.addDirectoryItems(handle, built, len(built))
    xbmcplugin.setContent(handle, content)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)

def _stream_base():
    return ADDON.getSettingString("stream_server_url").strip().rstrip("/") \
        or "http://localhost:3100"


def _stream_api_key():
    return ADDON.getSettingString("stream_server_api_key").strip()


def _fail_playback(handle, message):
    """Report resolution failure to Kodi, then tell the viewer why."""
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
    try:
        xbmcgui.Dialog().notification(
            "Unable to play", message, xbmcgui.NOTIFICATION_ERROR, 7000)
    except Exception as exc:  # noqa: BLE001 - the resolve signal already went out
        log("playback notification failed: {}".format(exc), xbmc.LOGWARNING)


def _play(handle, params):
    """Resolve the final stream first; only then report success to Kodi.

    Every path ends in exactly one setResolvedUrl call. The stream-server bearer
    stays in this process, and the resolved URL is never logged in full
    because provider links can embed credentials.
    """
    try:
        kind, tmdb_id, season, episode = resolver.validate_play_params(params)
        url = resolver.resolve_url(
            _stream_base(), kind, tmdb_id, season, episode,
            params.get("selection_id"), params.get("playback_intent_id"))
        request_id = uuid.uuid4().hex
        log("resolving stream: {} request_id={}".format(url, request_id))
        stream = resolver.resolve_stream(
            url, _stream_api_key(), request_id=request_id)
        log("resolved stream: host={} provider={} resolution={} fromCache={} request_id={}".format(
            urlparse(stream.url).hostname, stream.provider, stream.resolution,
            stream.from_cache, stream.request_id))
        item = xbmcgui.ListItem(path=stream.url)
        item.setContentLookup(False)
    except resolver.ResolveError as exc:
        log("playback resolution failed: status={} error={!r} request_id={} message={!r}".format(
            exc.status, exc.error, exc.request_id, exc.message), xbmc.LOGWARNING)
        _fail_playback(handle, exc.message)
        return
    except Exception as exc:  # noqa: BLE001 - never leave Kodi resolving
        log("unexpected playback-resolution error: {!r}".format(exc), xbmc.LOGERROR)
        _fail_playback(handle, resolver.MSG_SERVER)
        return

    xbmcplugin.setResolvedUrl(handle, True, item)


def dispatch(handle, params):
    info = params.get('info')
    list_route = LIST_ROUTES.get(info)
    if list_route is None:
        if info == 'play':
            _play(handle, params)
            return

        log('unknown info={!r}'.format(info))
        render(handle, 'videos', [])
        return
    render(handle, CONTENT.get(info, 'videos'), list_route(WatchService(), params))


if __name__ == '__main__':
    _handle = int(sys.argv[1])
    _params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
    dispatch(_handle, _params)
