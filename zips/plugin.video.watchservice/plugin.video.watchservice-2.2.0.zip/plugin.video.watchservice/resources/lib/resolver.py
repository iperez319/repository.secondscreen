# -*- coding: utf-8 -*-
"""Playback resolution against the stream server's JSON resolve API.

The add-on resolves the final media URL itself, then reports success to Kodi.
It never hands Kodi a resolver URL (the old ``/Torrents`` -> 302 flow). That way
every failure, whether a timeout, an HTTP error, or a bad response, can end in
``setResolvedUrl(False)`` plus a message, and not a busy overlay that never
closes.

Contract (infuse-jellyfin-mock ``docs/api.md`` "Stream Resolution (JSON API)"):

    GET {base}/api/streams/movie/{tmdbId}/resolve
    GET {base}/api/streams/tv/{tmdbId}/{season}/{episode}/resolve   (display numbering)
        ?selection_id=...&playback_intent_id=...
    200 {"url": ..., "resolution": ..., "provider": ..., "fromCache": ...}
    4xx/5xx {"error": ..., "message": <short, safe to display>}

Standard library only and no ``xbmc`` import, so it runs under plain unittest.
The resolved URL can carry provider credentials (Torbox embeds its token), so
callers must never log it in full.
"""
import json
import socket
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener

# Above the server's 12s live deadline (STREAM_LIVE_DEADLINE_MS), so a slow
# resolve normally comes back as the server's own 504 message.
RESOLVE_TIMEOUT_S = 20
# A resolve response is a small JSON document; never read more than this.
MAX_BODY_BYTES = 64 * 1024

MSG_TIMEOUT = "Finding a stream took too long. Please try again."
MSG_AUTH = "Watch Service authentication failed. Check the stream server API key."
MSG_NOT_FOUND = "No playable stream was found."
MSG_SERVER = "Playback failed because of a server error."
MSG_UNREACHABLE = "Could not reach the stream server."
MSG_INVALID = "The stream server returned an invalid response."
MSG_BAD_EPISODE = "This episode could not be identified."
MSG_BAD_MOVIE = "This movie could not be identified."


class ResolveError(Exception):
    """Resolution failed; ``message`` is short and safe to show on the TV."""

    def __init__(self, message, status=None, error=None, request_id=None):
        super(ResolveError, self).__init__(message)
        self.message = message
        self.status = status
        self.error = error
        self.request_id = request_id


class ResolvedStream(object):
    def __init__(self, url, provider=None, resolution=None, from_cache=False,
                 request_id=None):
        self.url = url
        self.provider = provider
        self.resolution = resolution
        self.from_cache = from_cache
        self.request_id = request_id


class _NoRedirect(HTTPRedirectHandler):
    """Surface 3xx as HTTPError so Python never follows a link into media."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _param(params, key):
    value = params.get(key)
    if value is None:
        return None
    value = str(value).strip()
    return value or None


def _as_int(value, minimum):
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed >= minimum else None


def validate_play_params(params):
    """Return ``(kind, tmdb_id, season, episode)`` or raise ResolveError.

    Episodes use display numbering when supplied (the resolve API applies the
    episode-group map itself). A blank ``display_*`` is treated as absent.
    """
    kind = "movie" if params.get("kind") == "movie" else "episode"
    tmdb_id = _as_int(_param(params, "tmdb_id"), 1)
    if kind == "movie":
        if tmdb_id is None:
            raise ResolveError(MSG_BAD_MOVIE, error="invalid_params")
        return kind, tmdb_id, None, None

    season = _param(params, "display_season") or _param(params, "season")
    episode = _param(params, "display_episode") or _param(params, "episode")
    season = _as_int(season, 0)
    episode = _as_int(episode, 1)
    if tmdb_id is None or season is None or episode is None:
        raise ResolveError(MSG_BAD_EPISODE, error="invalid_params")
    return kind, tmdb_id, season, episode


def resolve_url(base, kind, tmdb_id, season=None, episode=None,
                selection_id=None, playback_intent_id=None):
    """Build the JSON resolve URL for a movie or episode."""
    if kind == "movie":
        url = "{}/api/streams/movie/{}/resolve".format(base, tmdb_id)
    else:
        url = "{}/api/streams/tv/{}/{}/{}/resolve".format(
            base, tmdb_id, season, episode)

    query = {}
    if selection_id:
        query["selection_id"] = selection_id
    if playback_intent_id:
        query["playback_intent_id"] = playback_intent_id
    if query:
        url = "{}?{}".format(url, urlencode(query))
    return url


def _parse_json(raw):
    try:
        return json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        return None


def _is_timeout(exc):
    return isinstance(exc, (socket.timeout, TimeoutError)) or (
        isinstance(exc, URLError)
        and isinstance(exc.reason, (socket.timeout, TimeoutError)))


def _http_error(exc, request_id):
    """Classify an HTTP error response into a ResolveError (returned)."""
    status = exc.code
    if exc.headers is not None:
        request_id = exc.headers.get("X-Request-Id") or request_id
    if 300 <= status < 400:
        return ResolveError(MSG_INVALID, status=status, error="unexpected_redirect",
                            request_id=request_id)

    try:
        body = _parse_json(exc.read(MAX_BODY_BYTES))
    except Exception:  # noqa: BLE001 - the status alone still classifies it
        body = None
    error = body.get("error") if isinstance(body, dict) else None
    message = body.get("message") if isinstance(body, dict) else None
    if not isinstance(message, str) or not message.strip():
        if status in (401, 403):
            message = MSG_AUTH
        elif status == 404:
            message = MSG_NOT_FOUND
        elif status == 504:
            message = MSG_TIMEOUT
        else:
            message = MSG_SERVER
    return ResolveError(message.strip(), status=status,
                        error=error if isinstance(error, str) else None,
                        request_id=request_id)


def _valid_media_url(url):
    if not isinstance(url, str) or not url.strip():
        return False
    parsed = urlparse(url.strip())
    return parsed.scheme in ("http", "https") and bool(parsed.netloc)


def resolve_stream(url, api_key, timeout=RESOLVE_TIMEOUT_S, request_id=None):
    """Resolve ``url`` to a playable stream or raise ResolveError."""
    headers = {"Accept": "application/json"}
    if request_id:
        headers["X-Request-Id"] = request_id
    if api_key:
        headers["Authorization"] = "Bearer {}".format(api_key)

    opener = build_opener(_NoRedirect())
    try:
        with opener.open(Request(url, headers=headers, method="GET"),
                         timeout=timeout) as response:
            request_id = response.headers.get("X-Request-Id") or request_id
            raw = response.read(MAX_BODY_BYTES)
    except HTTPError as exc:
        try:
            failure = _http_error(exc, request_id)
        finally:
            exc.close()
        raise failure
    except Exception as exc:  # noqa: BLE001 - URLError/OSError/timeout
        if _is_timeout(exc):
            raise ResolveError(MSG_TIMEOUT, error="timeout", request_id=request_id)
        raise ResolveError(MSG_UNREACHABLE, error="unreachable",
                           request_id=request_id)

    # Unknown paths on the server answer 200 {}; only a real URL is success.
    body = _parse_json(raw)
    stream_url = body.get("url") if isinstance(body, dict) else None
    if not _valid_media_url(stream_url):
        raise ResolveError(MSG_INVALID, status=200, error="invalid_response",
                           request_id=request_id)
    return ResolvedStream(
        stream_url.strip(),
        provider=body.get("provider"),
        resolution=body.get("resolution"),
        from_cache=bool(body.get("fromCache")),
        request_id=request_id,
    )
