# -*- coding: utf-8 -*-
"""Playback resolution lifecycle tests runnable outside Kodi with stdlib unittest.

The resolver tests talk to a real local HTTP server, so redirect handling,
timeouts and error bodies go through the actual urllib stack.
"""
import importlib
import json
import os
import socket
import sys
import threading
import time
import types
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest import mock


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from resources.lib import resolver  # noqa: E402


class _Handler(BaseHTTPRequestHandler):
    routes = {}
    requests = []

    def do_GET(self):  # noqa: N802 - http.server naming
        path = self.path.split("?", 1)[0]
        type(self).requests.append({"path": self.path, "headers": dict(self.headers)})
        status, headers, body, delay = type(self).routes.get(
            path, (404, {}, b"", 0))
        if delay:
            time.sleep(delay)
        self.send_response(status)
        for key, value in headers.items():
            self.send_header(key, value)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def log_message(self, *_args):
        pass


def _json(status, payload, headers=None, delay=0):
    merged = {"Content-Type": "application/json"}
    merged.update(headers or {})
    return status, merged, json.dumps(payload).encode("utf-8"), delay


EPISODE_PATH = "/api/streams/tv/10/1/2/resolve"
MOVIE_PATH = "/api/streams/movie/550/resolve"


class ResolverTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        cls.server.daemon_threads = True
        cls.base = "http://127.0.0.1:{}".format(cls.server.server_address[1])
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def setUp(self):
        _Handler.routes = {}
        _Handler.requests = []

    def _resolve(self, path, api_key="", timeout=5, request_id="req-1"):
        return resolver.resolve_stream(
            self.base + path, api_key, timeout=timeout, request_id=request_id)

    def _assert_fails(self, path, message, **kwargs):
        with self.assertRaises(resolver.ResolveError) as ctx:
            self._resolve(path, **kwargs)
        self.assertEqual(ctx.exception.message, message)
        return ctx.exception

    def test_episode_success_sends_bearer_and_request_id(self):
        _Handler.routes[EPISODE_PATH] = _json(200, {
            "url": "https://media.example/episode.mkv",
            "provider": "Torbox", "resolution": "1080p", "fromCache": True,
        }, headers={"X-Request-Id": "req-1"})
        url = resolver.resolve_url(self.base, "episode", 10, 1, 2,
                                   selection_id="a b", playback_intent_id="intent")
        stream = resolver.resolve_stream(url, "secret", timeout=5, request_id="req-1")

        self.assertEqual(stream.url, "https://media.example/episode.mkv")
        self.assertEqual(stream.provider, "Torbox")
        self.assertTrue(stream.from_cache)
        self.assertEqual(stream.request_id, "req-1")
        sent = _Handler.requests[-1]
        self.assertIn("selection_id=a+b", sent["path"])
        self.assertIn("playback_intent_id=intent", sent["path"])
        self.assertEqual(sent["headers"].get("Authorization"), "Bearer secret")
        self.assertEqual(sent["headers"].get("X-Request-Id"), "req-1")

    def test_movie_success_without_key_sends_no_bearer(self):
        _Handler.routes[MOVIE_PATH] = _json(200, {"url": "https://media.example/movie.mkv"})
        stream = resolver.resolve_stream(
            resolver.resolve_url(self.base, "movie", 550), "", timeout=5)
        self.assertEqual(stream.url, "https://media.example/movie.mkv")
        self.assertNotIn("Authorization", _Handler.requests[-1]["headers"])

    def test_backend_messages_are_surfaced(self):
        cases = [
            (404, "Stream not found", "No playable stream could be resolved."),
            (409, "Dub not available", "English audio track is not available."),
            (500, "Stream resolution failed", "Torbox file listing failed."),
            (504, "Stream resolution timed out", "Finding a stream took too long. Please try again."),
        ]
        for status, error, message in cases:
            with self.subTest(status=status):
                _Handler.routes[EPISODE_PATH] = _json(
                    status, {"error": error, "message": message},
                    headers={"X-Request-Id": "server-id"})
                exc = self._assert_fails(EPISODE_PATH, message)
                self.assertEqual(exc.status, status)
                self.assertEqual(exc.error, error)
                self.assertEqual(exc.request_id, "server-id")

    def test_status_fallbacks_when_body_has_no_message(self):
        cases = [
            (401, {"error": "Unauthorized"}, resolver.MSG_AUTH),
            (403, {"error": "Forbidden"}, resolver.MSG_AUTH),
            (404, {}, resolver.MSG_NOT_FOUND),
            (504, {}, resolver.MSG_TIMEOUT),
            (502, {}, resolver.MSG_SERVER),
        ]
        for status, body, message in cases:
            with self.subTest(status=status):
                _Handler.routes[EPISODE_PATH] = _json(status, body)
                self._assert_fails(EPISODE_PATH, message)

        _Handler.routes[EPISODE_PATH] = (500, {}, b"<html>oops</html>", 0)
        self._assert_fails(EPISODE_PATH, resolver.MSG_SERVER)

    def test_timeout(self):
        _Handler.routes[EPISODE_PATH] = _json(
            200, {"url": "https://media.example/x.mkv"}, delay=1)
        exc = self._assert_fails(EPISODE_PATH, resolver.MSG_TIMEOUT, timeout=0.2)
        self.assertEqual(exc.error, "timeout")

    def test_redirect_is_not_followed(self):
        _Handler.routes[EPISODE_PATH] = (302, {"Location": self.base + "/media.mkv"}, b"", 0)
        _Handler.routes["/media.mkv"] = (200, {}, b"video bytes", 0)
        exc = self._assert_fails(EPISODE_PATH, resolver.MSG_INVALID)
        self.assertEqual(exc.error, "unexpected_redirect")
        self.assertEqual([r["path"] for r in _Handler.requests], [EPISODE_PATH])

    def test_invalid_success_bodies(self):
        bodies = [
            (200, {}, b"{}", 0),  # the server's unknown-path shim
            (200, {}, b"not json", 0),
            _json(200, ["https://media.example/x.mkv"]),
            _json(200, {"url": ""}),
            _json(200, {"url": "ftp://media.example/x.mkv"}),
            _json(200, {"url": "not a url"}),
        ]
        for route in bodies:
            with self.subTest(body=route[2]):
                _Handler.routes[EPISODE_PATH] = route
                exc = self._assert_fails(EPISODE_PATH, resolver.MSG_INVALID)
                self.assertEqual(exc.error, "invalid_response")

    def test_unreachable_server(self):
        sock = socket.socket()
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
        sock.close()
        with self.assertRaises(resolver.ResolveError) as ctx:
            resolver.resolve_stream(
                "http://127.0.0.1:{}{}".format(port, EPISODE_PATH), "", timeout=2)
        self.assertEqual(ctx.exception.message, resolver.MSG_UNREACHABLE)


class ValidatePlayParamsTests(unittest.TestCase):
    def test_episode_requires_identifiers(self):
        for params in (
            {"season": "1", "episode": "2"},
            {"tmdb_id": "10", "episode": "2"},
            {"tmdb_id": "10", "season": "1"},
            {"tmdb_id": "None", "season": "1", "episode": "2"},
            {"tmdb_id": "10", "season": "1", "episode": "0"},
            {"tmdb_id": "10", "season": "-1", "episode": "2"},
        ):
            with self.subTest(params=params):
                with self.assertRaises(resolver.ResolveError) as ctx:
                    resolver.validate_play_params(params)
                self.assertEqual(ctx.exception.message, resolver.MSG_BAD_EPISODE)

    def test_movie_requires_tmdb_id(self):
        with self.assertRaises(resolver.ResolveError) as ctx:
            resolver.validate_play_params({"kind": "movie", "tmdb_id": ""})
        self.assertEqual(ctx.exception.message, resolver.MSG_BAD_MOVIE)
        self.assertEqual(
            resolver.validate_play_params({"kind": "movie", "tmdb_id": "550"}),
            ("movie", 550, None, None))

    def test_display_numbering(self):
        base = {"tmdb_id": "10", "season": "1", "episode": "13"}
        self.assertEqual(resolver.validate_play_params(base), ("episode", 10, 1, 13))
        self.assertEqual(
            resolver.validate_play_params(dict(base, display_season="2", display_episode="1")),
            ("episode", 10, 2, 1))
        self.assertEqual(
            resolver.validate_play_params(dict(base, display_season="", display_episode="")),
            ("episode", 10, 1, 13))
        self.assertEqual(
            resolver.validate_play_params({"tmdb_id": "10", "season": "0", "episode": "3"}),
            ("episode", 10, 0, 3))


class _ListItem(object):
    def __init__(self, path=""):
        self.path = path
        self.content_lookup = None

    def setContentLookup(self, value):  # noqa: N802 - Kodi API naming
        self.content_lookup = value


class PluginPlayTests(unittest.TestCase):
    def setUp(self):
        self.resolved = []
        self.notifications = []
        self.logs = []
        settings = {"stream_server_url": "http://stream.local/", "stream_server_api_key": "key"}

        xbmc = types.ModuleType("xbmc")
        xbmc.LOGINFO, xbmc.LOGWARNING, xbmc.LOGERROR = 1, 2, 3
        xbmcplugin = types.ModuleType("xbmcplugin")
        xbmcplugin.setResolvedUrl = lambda handle, ok, item: self.resolved.append((handle, ok, item))
        xbmcgui = types.ModuleType("xbmcgui")
        xbmcgui.ListItem = _ListItem
        xbmcgui.NOTIFICATION_ERROR = "error"
        xbmcgui.Dialog = lambda: types.SimpleNamespace(
            notification=lambda *args: self.notifications.append(args))
        xbmcaddon = types.ModuleType("xbmcaddon")
        xbmcaddon.Addon = lambda *_args: types.SimpleNamespace(
            getSettingString=lambda key: settings.get(key, ""))
        wsapi = types.ModuleType("resources.lib.wsapi")
        wsapi.WatchService = object
        wsapi.log = lambda msg, *_args: self.logs.append(msg)

        self.modules = mock.patch.dict(sys.modules, {
            "xbmc": xbmc, "xbmcplugin": xbmcplugin, "xbmcgui": xbmcgui,
            "xbmcaddon": xbmcaddon, "resources.lib.wsapi": wsapi,
        })
        self.modules.start()
        sys.modules.pop("plugin", None)
        self.plugin = importlib.import_module("plugin")

    def tearDown(self):
        self.modules.stop()

    def _play(self, params, resolve):
        with mock.patch.object(resolver, "resolve_stream", resolve):
            self.plugin.dispatch(7, dict({"info": "play"}, **params))

    def test_success_resolves_final_url_once(self):
        calls = []

        def resolve(url, api_key, request_id=None):
            calls.append((url, api_key))
            return resolver.ResolvedStream(
                "https://cdn.example/x.mkv?token=provider-secret",
                provider="Torbox", request_id=request_id)

        self._play({"tmdb_id": "10", "season": "1", "episode": "2"}, resolve)
        self.assertEqual(calls, [("http://stream.local/api/streams/tv/10/1/2/resolve", "key")])
        self.assertEqual(len(self.resolved), 1)
        handle, ok, item = self.resolved[0]
        self.assertEqual((handle, ok), (7, True))
        self.assertEqual(item.path, "https://cdn.example/x.mkv?token=provider-secret")
        self.assertIs(item.content_lookup, False)
        self.assertEqual(self.notifications, [])
        self.assertFalse(any("provider-secret" in line or "Bearer" in line for line in self.logs))

    def test_resolve_error_fails_with_notification(self):
        def resolve(*_args, **_kwargs):
            raise resolver.ResolveError("No playable stream could be resolved.", status=404)

        self._play({"tmdb_id": "10", "season": "1", "episode": "2"}, resolve)
        self.assertEqual([(h, ok) for h, ok, _item in self.resolved], [(7, False)])
        self.assertEqual(len(self.notifications), 1)
        self.assertEqual(self.notifications[0][1], "No playable stream could be resolved.")

    def test_invalid_params_fail_without_network(self):
        def resolve(*_args, **_kwargs):
            self.fail("resolve_stream must not be called for invalid params")

        self._play({"tmdb_id": "10"}, resolve)
        self.assertEqual([ok for _h, ok, _item in self.resolved], [False])
        self.assertEqual(self.notifications[0][1], resolver.MSG_BAD_EPISODE)

    def test_unexpected_exception_still_fails_resolution(self):
        def resolve(*_args, **_kwargs):
            raise RuntimeError("boom")

        self._play({"kind": "movie", "tmdb_id": "550"}, resolve)
        self.assertEqual([ok for _h, ok, _item in self.resolved], [False])
        self.assertEqual(self.notifications[0][1], resolver.MSG_SERVER)


if __name__ == "__main__":
    unittest.main()
