# -*- coding: utf-8 -*-
"""WRITE service for plugin.video.watchservice — Kodi-side agent for the backend.

A thin orchestrator (design §8.2): it builds one player monitor feeding two
sinks and runs an adaptive tick loop.

  * durable_sink — mirrors playback to the watch-service over HTTP, byte-for-byte
    as this service always has (the sacred path; unchanged semantics).
  * companion_link — a supervised WebSocket to kodi-companion carrying live
    session/player state for the phone and Live Activity.

The companion link is entirely optional and self-healing: with it disabled or
unconfigured the addon behaves exactly like the original single-purpose service
(the `companion_enabled` kill switch reverts to today's behavior instantly).

Read path (plugin.py) is untouched.
"""
import xbmc
import xbmcaddon

from resources.lib.service.companion_link import CompanionLink
from resources.lib.service.durable_sink import DurableSink
from resources.lib.service.overlay import ActionOverlay
from resources.lib.service.player_monitor import WSPlayer
from resources.lib.service.state import SessionState
from resources.lib.wsapi import log as ws_log

ADDON_ID = "plugin.video.watchservice"

# Adaptive tick: fast while something is playing (drift ticks, media probe),
# idle otherwise. 0.25 s is ample — nothing here animates per frame (§8.2).
_TICK_ACTIVE_S = 0.25
_TICK_IDLE_S = 1.0


class _Log(object):
    """Adapts wsapi's `log(msg, level)` to the .info/.warning/.debug shape the
    companion link expects."""

    def info(self, msg):
        ws_log(msg, xbmc.LOGINFO)

    def warning(self, msg):
        ws_log(msg, xbmc.LOGWARNING)

    def debug(self, msg):
        ws_log(msg, xbmc.LOGDEBUG)


def _setting_bool(addon, key):
    getter = getattr(addon, "getSettingBool", None)
    if getter:
        try:
            return getter(key)
        except Exception:  # noqa: BLE001 - fall back to the string form
            pass
    return (addon.getSetting(key) or "").lower() == "true"


def _companion_ws_url(raw):
    url = (raw or "").strip()
    if url.startswith("http://"):
        url = "ws://" + url[len("http://"):]
    elif url.startswith("https://"):
        url = "wss://" + url[len("https://"):]
    elif not url.startswith("ws://") and not url.startswith("wss://"):
        url = "ws://" + url
    return url.rstrip("/") + "/ws"


def _build_companion(state, log):
    """Construct the companion link from settings, or None when disabled/unset —
    in which case the addon runs durable-only, exactly as before."""
    addon = xbmcaddon.Addon(ADDON_ID)
    if not _setting_bool(addon, "companion_enabled"):
        log.info("companion link disabled by setting")
        return None
    url = (addon.getSetting("companion_url") or "").strip()
    token = (addon.getSetting("companion_token") or "").strip()
    if not url or not token:
        log.warning("companion link not configured (url/token) — durable-only mode")
        return None
    return CompanionLink(_companion_ws_url(url), token, state, log, app_id=ADDON_ID)


def main():
    log = _Log()
    log.info("watch-service service starting (v2: durable + companion)")

    state = SessionState()
    sinks = [DurableSink()]
    companion = _build_companion(state, log)
    if companion:
        companion.start()
        sinks.append(companion)

    player = WSPlayer(state, sinks)
    overlay = ActionOverlay(state, log)
    monitor = xbmc.Monitor()
    try:
        while not monitor.abortRequested():
            interval = _TICK_ACTIVE_S if state.active else _TICK_IDLE_S
            if monitor.waitForAbort(interval):
                break
            player.tick()
            overlay.tick()
    finally:
        overlay.close()
        if companion:
            companion.stop()
        del player
        del monitor
        log.info("watch-service service stopped")


if __name__ == "__main__":
    main()
