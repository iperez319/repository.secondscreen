# -*- coding: utf-8 -*-
"""Command executor for the companion relay.

The companion is the router; this addon is the only component that actually
touches Kodi playback. Keep the allowlist explicit and return command.result
errors instead of letting malformed client input crash the link thread.
"""
import json
import time

import xbmc

_WINDOW_GRACE_S = 2.0
_TMDB_HELPER_PREFIX = "plugin://plugin.video.themoviedb.helper/"


def _as_float(value, default=None):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _as_int(value, default=None):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _current_position(state, player):
    try:
        return float(player.getTime())
    except RuntimeError:
        return float(state.last_pos or 0.0)


def _player_state(state, phase=None):
    player = xbmc.Player()
    phase = phase or (state.phase if state.phase in ("playing", "paused", "buffering") else "playing")
    try:
        pos = float(player.getTime())
    except RuntimeError:
        pos = state.last_pos
    state.last_pos = max(0.0, pos)
    return {
        "phase": phase,
        "positionS": max(0.0, pos),
        "rate": 1.0 if phase == "playing" else 0.0,
        "anchorTs": int(time.time() * 1000),
    }


def _ok(cmd_id, state, phase=None):
    result = {"cmdId": cmd_id, "ok": True}
    if state.active:
        result["resultingState"] = _player_state(state, phase)
    return result


def _err(cmd_id, code):
    return {"cmdId": cmd_id, "ok": False, "error": code}


def _jsonrpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    try:
        decoded = json.loads(raw)
    except (TypeError, ValueError):
        return None
    if decoded.get("error"):
        raise RuntimeError(decoded.get("error"))
    return decoded.get("result")


def _validated_action(action_id, state, player):
    action = state.action_by_id(action_id)
    if not action:
        return None, "unknown_action"
    window = action.get("window") or {}
    start = _as_float(window.get("startS"), 0.0)
    end = _as_float(window.get("endS"), None)
    pos = _current_position(state, player)
    if pos + _WINDOW_GRACE_S < start:
        return None, "window_expired"
    if end is not None and pos > end + _WINDOW_GRACE_S:
        return None, "window_expired"
    return action, None


def _execute_skip(cmd_id, action, state, player):
    execute = action.get("execute") or {}
    if execute.get("type") != "seek":
        return _err(cmd_id, "invalid_action")
    target = _as_float(execute.get("toS"))
    if target is None:
        return _err(cmd_id, "invalid_action")
    current = _current_position(state, player)
    if target <= current:
        return _err(cmd_id, "window_expired")
    player.seekTime(target)
    state.last_pos = target
    return _ok(cmd_id, state)


def _execute_play_next(cmd_id, action, state, player):
    execute = action.get("execute") or {}
    plugin_url = execute.get("pluginUrl")
    if execute.get("type") != "play_next" or not plugin_url:
        return _err(cmd_id, "invalid_action")
    player.play(plugin_url)
    return _ok(cmd_id, state, "playing")


def _safe_plugin_url(url):
    return isinstance(url, str) and url.startswith(_TMDB_HELPER_PREFIX)


def execute(payload, state, log):
    cmd_id = payload.get("cmdId") or ""
    if cmd_id and state.seen_command(cmd_id):
        return state.command_result(cmd_id)

    action = payload.get("action") or {}
    action_type = action.get("type")
    player = xbmc.Player()

    try:
        result = _execute(action_type, action, cmd_id, state, player)
    except Exception as exc:  # noqa: BLE001 - report to companion, don't crash link thread
        log.warning("command {} failed: {}".format(action_type, exc))
        result = _err(cmd_id, "execution_failed")

    if cmd_id:
        state.record_command(cmd_id, result)
    return result


def _execute(action_type, action, cmd_id, state, player):
    if action_type == "playpause":
        if not player.isPlaying():
            return _err(cmd_id, "no_active_player")
        next_phase = "paused" if state.phase == "playing" else "playing"
        player.pause()
        state.phase = next_phase
        return _ok(cmd_id, state, next_phase)

    if action_type == "stop":
        if not player.isPlaying():
            return _err(cmd_id, "no_active_player")
        player.stop()
        state.active = False
        return {"cmdId": cmd_id, "ok": True}

    if action_type == "seek":
        if not player.isPlaying():
            return _err(cmd_id, "no_active_player")
        target = _as_float(action.get("toS"))
        if target is None:
            return _err(cmd_id, "invalid_command")
        player.seekTime(max(0.0, target))
        state.last_pos = max(0.0, target)
        return _ok(cmd_id, state)

    if action_type == "seek_by":
        if not player.isPlaying():
            return _err(cmd_id, "no_active_player")
        delta = _as_float(action.get("deltaS"))
        if delta is None:
            return _err(cmd_id, "invalid_command")
        target = max(0.0, _current_position(state, player) + delta)
        if state.last_dur:
            target = min(float(state.last_dur), target)
        player.seekTime(target)
        state.last_pos = target
        return _ok(cmd_id, state)

    if action_type == "set_speed":
        rate = _as_float(action.get("rate"))
        if rate is None:
            return _err(cmd_id, "invalid_command")
        if not hasattr(player, "setSpeed"):
            return _err(cmd_id, "unsupported")
        speed = int(round(rate))
        player.setSpeed(speed)
        state.phase = "paused" if speed == 0 else "playing"
        return _ok(cmd_id, state, state.phase)

    if action_type == "skip":
        action_id = action.get("actionId")
        current_action, error = _validated_action(action_id, state, player)
        if error:
            return _err(cmd_id, error)
        return _execute_skip(cmd_id, current_action, state, player)

    if action_type == "play_next":
        action_id = action.get("actionId")
        current_action, error = _validated_action(action_id, state, player)
        if error:
            return _err(cmd_id, error)
        return _execute_play_next(cmd_id, current_action, state, player)

    if action_type == "play":
        plugin_url = action.get("pluginUrl")
        if not _safe_plugin_url(plugin_url):
            return _err(cmd_id, "invalid_command")
        player.play(plugin_url)
        return _ok(cmd_id, state, "playing")

    if action_type == "set_subtitle":
        index = _as_int(action.get("index"))
        enabled = bool(action.get("enabled", True))
        if hasattr(player, "showSubtitles"):
            player.showSubtitles(enabled)
        if enabled and index is not None and hasattr(player, "setSubtitleStream"):
            player.setSubtitleStream(index)
        return _ok(cmd_id, state)

    if action_type == "set_audio":
        index = _as_int(action.get("index"))
        if index is None:
            return _err(cmd_id, "invalid_command")
        if not hasattr(player, "setAudioStream"):
            return _err(cmd_id, "unsupported")
        player.setAudioStream(index)
        return _ok(cmd_id, state)

    if action_type == "input.text":
        text = action.get("text")
        if text is None:
            return _err(cmd_id, "invalid_command")
        _jsonrpc("Input.SendText", {"text": str(text), "done": bool(action.get("done", True))})
        return _ok(cmd_id, state)

    if action_type == "input.nav":
        key = action.get("key")
        methods = {
            "up": "Input.Up",
            "down": "Input.Down",
            "left": "Input.Left",
            "right": "Input.Right",
            "select": "Input.Select",
            "back": "Input.Back",
        }
        method = methods.get(key)
        if not method:
            return _err(cmd_id, "invalid_command")
        _jsonrpc(method)
        return _ok(cmd_id, state)

    if action_type == "dismiss_dialog":
        _jsonrpc("Input.Back")
        return _ok(cmd_id, state)

    return _err(cmd_id, "not_implemented")
