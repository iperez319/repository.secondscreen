# -*- coding: utf-8 -*-
"""The live sink: a supervised WebSocket link to kodi-companion.

Owns its own thread, which owns the socket exclusively (a Kodi player callback
must never block on network I/O — design §8.2). Callbacks and the tick loop only
enqueue; the link thread drains, assigns per-connection sequence numbers, and
sends. On disconnect it buffers transitions in a bounded, newest-wins outbox and
reconnects with exponential backoff + full jitter, forever, logging state
changes rather than every attempt.

The companion always requests a full snapshot on connect, so the snapshot
re-baselines state wholesale; the outbox is a belt-and-suspenders flush of
transitions raised while offline (02-websocket-protocol §6).
"""
import json
import random
import threading
import time
import uuid
from collections import deque

import xbmc
import xbmcgui

from resources.lib.vendor import websocket

from . import commands
from . import events

_HOME_WINDOW = 10000
_ONLINE_PROP = "WatchService.CompanionOnline"
_OUTBOX_MAX = 50
_PING_INTERVAL_S = 15.0
# The recv timeout also bounds how quickly queued sends (a pause, a seek) flush,
# since the link thread interleaves recv and drain in one loop. 0.25 s keeps
# transition latency imperceptible on a LAN without busy-spinning.
_RECV_TIMEOUT_S = 0.25
# The initial TCP connect + WebSocket upgrade get a longer, separate budget than
# the serve loop's recv timeout: 0.25 s is right for send/recv interleaving but
# too tight for a connect when the device is busy (decoding 4K).
_CONNECT_TIMEOUT_S = 5.0
# Reconnect backoff cap. Kept low (not the design's 60 s) so a companion that
# appears after Kodi is picked up within ~10 s. Safe because logging is
# state-change-only and a refused connect is instant — no spam on a LAN.
_BACKOFF_CAP_S = 10.0
# Dead-peer detection: if no frame arrives within this window the socket is
# treated as dead and we reconnect. On a healthy link inbound traffic is
# guaranteed at least every ~15 s (the companion pings every 15 s, and its pongs
# answer our own 15 s pings), so 35 s means ~2 missed pings — matching the
# companion's own liveness rule (design §7). Without this, a peer that vanishes
# without a TCP RST (a container restart against a black-holed connection) leaves
# recv() timing out and pings buffering into the void, so the link would spin
# forever believing it is still connected.
_DEAD_AFTER_S = 35.0
_CAPABILITIES = ["input-nav", "overlay"]


class CompanionLink(object):
    def __init__(self, url, token, state, log, app_id="plugin.video.watchservice",
                 dead_after_s=_DEAD_AFTER_S):
        self._url = url
        self._token = token
        self._state = state
        self._log = log
        self._app_id = app_id
        self._dead_after_s = dead_after_s

        self._lock = threading.Lock()
        self._live = deque()  # (type, payload) to send while connected
        self._outbox = deque(maxlen=_OUTBOX_MAX)  # transitions buffered while offline
        self._connected = False
        self._seq = 0  # per-connection, touched only by the link thread
        self._ws = None
        self._stop = threading.Event()
        self._thread = None
        self._logged_state = None  # last logged up/down edge
        self._backoff = 1.0  # reconnect backoff seconds; reset on a healthy connect

    # -- lifecycle ----------------------------------------------------------

    def start(self):
        self._thread = threading.Thread(target=self._run, name="companion-link", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        try:
            if self._ws:
                self._ws.close()
        except Exception:  # noqa: BLE001 - teardown is best-effort
            pass
        if self._thread:
            self._thread.join(timeout=2.0)
        self._set_window_prop(False)

    # -- sink interface (called from the player monitor thread) -------------

    def handle(self, event):
        kind = event.kind
        if kind == events.AV_STARTED:
            if not event.descriptor:
                return  # companion needs an identified session
            self._enqueue("session.start", event.descriptor)
            self._enqueue("player.state", event.player_state)
        elif kind in (events.PAUSED, events.RESUMED):
            self._enqueue("player.state", event.player_state)
        elif kind == events.SEEK:
            self._enqueue("player.seek", event.player_state)
        elif kind == events.DRIFT:
            self._enqueue("player.state", event.player_state, drift=True)
        elif kind in (events.STOPPED, events.ENDED):
            reason = "stopped" if kind == events.STOPPED else "ended"
            self._enqueue(
                "session.end", {"reason": reason, "positionS": max(0.0, event.position_s)}
            )

    def handle_media(self, details):
        self._enqueue("session.media", details)

    # -- enqueue ------------------------------------------------------------

    def _enqueue(self, mtype, payload, drift=False):
        with self._lock:
            if self._connected:
                self._live.append((mtype, payload))
            elif not drift:
                # Buffer transitions only; compact player.state newest-wins.
                if mtype == "player.state":
                    self._outbox = deque(
                        (m for m in self._outbox if m[0] != "player.state"), maxlen=_OUTBOX_MAX
                    )
                self._outbox.append((mtype, payload))
            # drift ticks raised while offline are simply dropped.

    # -- link thread --------------------------------------------------------

    def _run(self):
        # Backoff is an instance attribute so _connect_and_serve can reset it the
        # moment a connection proves healthy (first inbound frame). The old
        # `backoff = 1.0` after the call was dead code — the call only returns on
        # shutdown, so backoff grew to the cap during an outage and never reset.
        self._backoff = 1.0
        while not self._stop.is_set():
            try:
                self._connect_and_serve()
            except Exception as exc:  # noqa: BLE001 - any failure → reconnect
                self._log_edge(False, exc)
            self._mark_disconnected()
            if self._stop.is_set():
                break
            # Full jitter: sleep a random slice of the growing window.
            self._stop.wait(random.uniform(0, min(self._backoff, _BACKOFF_CAP_S)))
            self._backoff = min(self._backoff * 2, _BACKOFF_CAP_S)

    def _connect_and_serve(self):
        # Longer budget for the connect + upgrade, then switch to the fast recv
        # timeout for the serve loop's send/recv interleaving.
        ws = websocket.create_connection(
            self._url,
            timeout=_CONNECT_TIMEOUT_S,
            header=["Authorization: Bearer {}".format(self._token)],
        )
        ws.settimeout(_RECV_TIMEOUT_S)
        self._ws = ws
        self._seq = 0
        self._log_edge(True, None)
        self._raw_send(
            "hello",
            {
                "role": "kodi",
                "app": self._app_id,
                "version": "2.0.0",
                "capabilities": _CAPABILITIES,
            },
        )
        last_ping = time.time()
        last_inbound = time.time()
        got_inbound = False
        try:
            while not self._stop.is_set():
                try:
                    raw = ws.recv()
                    last_inbound = time.time()
                    if not got_inbound:
                        # The peer is really talking (hello.ack / snapshot.request
                        # arrive at once): a healthy connection, so reset backoff
                        # for a fast recovery if it later drops. A rejected socket
                        # sends nothing and never gets here, so a misconfig can't
                        # hot-loop.
                        got_inbound = True
                        self._backoff = 1.0
                    self._handle_incoming(raw)
                except websocket.WebSocketTimeoutException:
                    pass  # no frame this interval — fall through to periodic work
                now = time.time()
                # Dead-peer detection: a silent socket (peer gone without an RST)
                # never raises from recv/send, so force a reconnect ourselves.
                if now - last_inbound > self._dead_after_s:
                    raise websocket.WebSocketConnectionClosedException("no inbound frames")
                self._drain_live()
                if now - last_ping >= _PING_INTERVAL_S:
                    last_ping = now
                    self._raw_send("ping", {})
        finally:
            # Always tear down this socket before reconnecting (also fixes an fd
            # leak — _mark_disconnected only nulls the reference).
            try:
                ws.close()
            except Exception:  # noqa: BLE001 - teardown is best-effort
                pass

    def _handle_incoming(self, raw):
        try:
            msg = json.loads(raw)
        except (ValueError, TypeError):
            return
        mtype = msg.get("type")
        if mtype == "snapshot.request":
            self._raw_send("snapshot", self._build_snapshot())
            self._flush_and_connect()
        elif mtype == "ping":
            self._raw_send("pong", {})
        elif mtype == "command":
            self._handle_command(msg.get("payload") or {})
        elif mtype == "session.segments":
            payload = msg.get("payload") or {}
            self._state.set_actions(payload.get("sessionId"), payload.get("actions") or [])
            self._log.debug("companion actions received: {}".format(len(self._state.actions)))
        # hello.ack / pong / unknown types: ignore (forward-compat).

    def _flush_and_connect(self):
        with self._lock:
            pending = list(self._outbox)
            self._outbox.clear()
            self._connected = True
            self._live.extendleft(reversed(pending))
        self._set_window_prop(True)

    def _drain_live(self):
        while True:
            with self._lock:
                if not self._live:
                    return
                mtype, payload = self._live.popleft()
            self._seq += 1
            self._raw_send(mtype, payload, seq=self._seq)

    def _build_snapshot(self):
        if self._state.active and self._state.descriptor:
            phase = self._state.phase if self._state.phase in ("playing", "paused") else "playing"
            player = {
                "phase": phase,
                "positionS": max(0.0, self._state.last_pos),
                "rate": 1.0 if phase == "playing" else 0.0,
                "anchorTs": int(time.time() * 1000),
            }
            return {"baseSeq": 0, "session": self._state.descriptor, "player": player, "gui": None}
        return {"baseSeq": 0, "session": None, "player": None, "gui": None}

    def _handle_command(self, payload):
        result = commands.execute(payload, self._state, self._log)
        self._raw_send("command.result", result)

    def _raw_send(self, mtype, payload, seq=None):
        frame = {
            "v": 1,
            "type": mtype,
            "id": uuid.uuid4().hex,
            "ts": int(time.time() * 1000),
            "payload": payload,
        }
        if seq is not None:
            frame["seq"] = seq
        self._ws.send(json.dumps(frame))

    def _mark_disconnected(self):
        with self._lock:
            self._connected = False
        self._ws = None
        self._set_window_prop(False)

    # -- diagnostics --------------------------------------------------------

    def _set_window_prop(self, online):
        try:
            xbmcgui.Window(_HOME_WINDOW).setProperty(_ONLINE_PROP, "true" if online else "false")
        except Exception:  # noqa: BLE001
            pass

    def _log_edge(self, up, exc):
        # Log only on state changes, never per attempt (avoids reconnect spam).
        if self._logged_state == up:
            return
        self._logged_state = up
        if up:
            self._log.info("companion link connected")
        else:
            self._log.warning("companion link down: {}".format(exc if exc else "closed"))
